#include "footballgod.h"
#include "fixtures3.h"




fixturescontwo::fixturescontwo()
{
   teamturn = 0;
   gamenumber = 1;
   strcpy(week,"gggggggggggggggg");
   strcpy(teamvteam24,"xggggggggggggggg");
   strcpy(teamvteam25,"gxgggggggggggggg");
   strcpy(teamvteam26,"ggxggggggggggggg");
   strcpy(teamvteam27,"gggxgggggggggggg");
   strcpy(teamvteam28,"ggggxggggggggggg");
   strcpy(teamvteam29,"gggggxgggggggggg");
   strcpy(teamvteam30,"ggggggxggggggggg");
   strcpy(teamvteam31,"gggggggxgggggggg");
   strcpy(teamvteam32,"ggggggggxggggggg");
   strcpy(teamvteam33,"gggggggggxgggggg");
   strcpy(teamvteam34,"ggggggggggxggggg");
   strcpy(teamvteam35,"gggggggggggxgggg");
   strcpy(teamvteam36,"ggggggggggggxggg");
   strcpy(teamvteam37,"gggggggggggggxgg");
   strcpy(teamvteam38,"ggggggggggggggxg");
   strcpy(teamvteam39,"gggggggggggggggx");
}


fixturescontwo::~fixturescontwo()
{
}



int fixturescontwo::teamchecker(int tc1)
{
  int tm1;
  tm1 = tc1;
  int p;

  if(tm1 == 24)
  {


    for(p = 15; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam24[p] == 'g')
           {
             teamvteam24[p] = 'x';
             week[p] = 'x';
             return p + 24 ;
           }

         }
  }


 if(tm1 == 25)
  {


    for(p = 15; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam25[p] == 'g')
           {
             teamvteam25[p] = 'x';
             week[p] = 'x';
             return p + 24;
           }

         }
  }

   if(tm1 == 26)
  {


    for(p = 15; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam26[p] == 'g')
           {
             teamvteam26[p] = 'x';
             week[p] = 'x';
             return p + 24;
           }

         }
  }


   if(tm1 == 27)
  {


    for(p = 15; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam27[p] == 'g')
           {
             teamvteam27[p] = 'x';
             week[p] = 'x';
             return p + 24;
           }

         }
  }


   if(tm1 == 28)
  {


    for(p = 15; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam28[p] == 'g')
           {
             teamvteam28[p] = 'x';
             week[p] = 'x';
             return p + 24;
           }

         }
  }

   if(tm1 == 29)
  {


    for(p = 15; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam29[p] == 'g')
           {
             teamvteam29[p] = 'x';
             week[p] = 'x';
             return p + 24;
           }

         }
  }


   if(tm1 == 30)
  {


    for(p = 15; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam30[p] == 'g')
           {
             teamvteam30[p] = 'x';
             week[p] = 'x';
             return p + 24;
           }

         }
  }

   if(tm1 == 31)
  {


    for(p = 15; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam31[p] == 'g')
           {
             teamvteam31[p] = 'x';
             week[p] = 'x';
             return p + 24;
           }

         }
  }

  if(tm1 == 32)
  {


    for(p = 0; p < 16; p++)
         {
           if(week[p] == 'g' && teamvteam32[p] == 'g')
           {
             teamvteam32[p] = 'x';
             week[p] = 'x';
             return p + 24;
           }

         }
  }

  if(tm1 == 33)
  {


    for(p = 0; p < 16; p++)
         {
           if(week[p] == 'g' && teamvteam33[p] == 'g')
           {
             teamvteam33[p] = 'x';
             week[p] = 'x';
             return p + 24;
           }

         }
  }

  if(tm1 == 34)
  {


    for(p = 0; p < 16; p++)
         {
           if(week[p] == 'g' && teamvteam34[p] == 'g')
           {
             teamvteam34[p] = 'x';
             week[p] = 'x';
             return p + 24;
           }

         }
  }

  if(tm1 == 35)
  {


    for(p = 0; p < 16; p++)
         {
           if(week[p] == 'g' && teamvteam35[p] == 'g')
           {
             teamvteam35[p] = 'x';
             week[p] = 'x';
             return p + 24;
           }

         }
  }

  if(tm1 == 36)
  {


    for(p = 0; p < 16; p++)
         {
           if(week[p] == 'g' && teamvteam36[p] == 'g')
           {
             teamvteam36[p] = 'x';
             week[p] = 'x';
             return p + 24;
           }

         }
  }

  if(tm1 == 37)
  {


    for(p = 0; p < 16; p++)
         {
           if(week[p] == 'g' && teamvteam37[p] == 'g')
           {
             teamvteam37[p] = 'x';
             week[p] = 'x';
             return p + 24;
           }

         }
  }

  if(tm1 == 38)
  {


    for(p = 0; p < 16; p++)
         {
           if(week[p] == 'g' && teamvteam38[p] == 'g')
           {
             teamvteam38[p] = 'x';
             week[p] = 'x';
             return p + 24;
           }

         }
  }

  if(tm1 == 39)
  {


    for(p = 0; p < 16; p++)
         {
           if(week[p] == 'g' && teamvteam39[p] == 'g')
           {
             teamvteam39[p] = 'x';
             week[p] = 'x';
             return p + 24;
           }

         }
  }

  return 40;
}








int fixturescontwo::checkgamenumber()
{
   return gamenumber;
}

void fixturescontwo::plusonegamenumber()
{
   gamenumber = gamenumber + 1;
}


void fixturescontwo::turnplus()
{
    teamturn = teamturn + 1;
    if (teamturn >= 8)
    {
        teamturn = 0;
        strcpy(week,"gggggggggggggggg");
    }

}






int fixturescontwo::checkturn()
{
  int p;
  int tm1;
  tm1 = 0;


  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam24[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam25[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam26[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam27[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam28[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam29[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam30[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam31[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam32[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam33[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1++;

   if(week[tm1] == 'g')
   {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam34[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam35[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam36[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam37[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam38[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam39[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  return 40;
}








int fixturescontwo::checkturntwo()
{
  int p;
  int tm1;
  tm1 = 15;


  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam39[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam38[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam37[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam36[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam35[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam34[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam33[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam32[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam31[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam30[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1--;

   if(week[tm1] == 'g')
   {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam29[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam28[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam27[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam26[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam25[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam24[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 24;
           }
    }
  }

  return 40;
}


void fixturescontwo::fullseasonthree()
{
teamturn = 0;
   gamenumber = 1;
   strcpy(week,"gggggggggggggggg");
   strcpy(teamvteam24,"xggggggggggggggg");
   strcpy(teamvteam25,"gxgggggggggggggg");
   strcpy(teamvteam26,"ggxggggggggggggg");
   strcpy(teamvteam27,"gggxgggggggggggg");
   strcpy(teamvteam28,"ggggxggggggggggg");
   strcpy(teamvteam29,"gggggxgggggggggg");
   strcpy(teamvteam30,"ggggggxggggggggg");
   strcpy(teamvteam31,"gggggggxgggggggg");
   strcpy(teamvteam32,"ggggggggxggggggg");
   strcpy(teamvteam33,"gggggggggxgggggg");
   strcpy(teamvteam34,"ggggggggggxggggg");
   strcpy(teamvteam35,"gggggggggggxgggg");
   strcpy(teamvteam36,"ggggggggggggxggg");
   strcpy(teamvteam37,"gggggggggggggxgg");
   strcpy(teamvteam38,"ggggggggggggggxg");
   strcpy(teamvteam39,"gggggggggggggggx");
}




void fixturescontwo::save(fstream& op)
{
  op.write(week, sizeof(week));
  op.write(teamvteam24, sizeof(teamvteam24));
  op.write(teamvteam25, sizeof(teamvteam25));
  op.write(teamvteam26, sizeof(teamvteam26));
  op.write(teamvteam27, sizeof(teamvteam27));
  op.write(teamvteam28, sizeof(teamvteam28));
  op.write(teamvteam29, sizeof(teamvteam29));
  op.write(teamvteam30, sizeof(teamvteam30));
  op.write(teamvteam31, sizeof(teamvteam31));
  op.write(teamvteam32, sizeof(teamvteam32));
  op.write(teamvteam33, sizeof(teamvteam33));
  op.write(teamvteam34, sizeof(teamvteam34));
  op.write(teamvteam35, sizeof(teamvteam35));
  op.write(teamvteam36, sizeof(teamvteam36));
  op.write(teamvteam37, sizeof(teamvteam37));
  op.write(teamvteam38, sizeof(teamvteam38));
  op.write(teamvteam39, sizeof(teamvteam39));
  op.write((char *)&teamturn, sizeof(teamturn));
  op.write((char *)&gamenumber, sizeof(gamenumber));
}

int fixturescontwo::load(fstream& ip)
{
  if(ip.eof())
  return 0;

  ip.read(week, sizeof(week));
  ip.read(teamvteam24, sizeof(teamvteam24));
  ip.read(teamvteam25, sizeof(teamvteam25));
  ip.read(teamvteam26, sizeof(teamvteam26));
  ip.read(teamvteam27, sizeof(teamvteam27));
  ip.read(teamvteam28, sizeof(teamvteam28));
  ip.read(teamvteam29, sizeof(teamvteam29));
  ip.read(teamvteam30, sizeof(teamvteam30));
  ip.read(teamvteam31, sizeof(teamvteam31));
  ip.read(teamvteam32, sizeof(teamvteam32));
  ip.read(teamvteam33, sizeof(teamvteam33));
  ip.read(teamvteam34, sizeof(teamvteam34));
  ip.read(teamvteam35, sizeof(teamvteam35));
  ip.read(teamvteam36, sizeof(teamvteam36));
  ip.read(teamvteam37, sizeof(teamvteam37));
  ip.read(teamvteam38, sizeof(teamvteam38));
  ip.read(teamvteam39, sizeof(teamvteam39));
  ip.read((char *)&teamturn, sizeof(teamturn));
  ip.read((char *)&gamenumber, sizeof(gamenumber));

  return 1;
}
