#include "footballgod.h"
#include "fixtureselite.h"




fixtureselite::fixtureselite()
{
    teamturn = 0;
    gamenumber = 1;
    strcpy(week,"gggggggg");
    strcpy(teamvteam0,"xggggggg");
    strcpy(teamvteam1,"gxgggggg");
    strcpy(teamvteam2,"ggxggggg");
    strcpy(teamvteam3,"gggxgggg");
    strcpy(teamvteam4,"ggggxggg");
    strcpy(teamvteam5,"gggggxgg");
    strcpy(teamvteam6,"ggggggxg");
    strcpy(teamvteam7,"gggggggx");
}


fixtureselite::~fixtureselite()
{
}



int fixtureselite::teamchecker(int tc1)
{

  int tm1;
  tm1 = tc1;
  int p;

  if(tm1 == 0)
  {


    for(p = 7; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam0[p] == 'g')
           {
             teamvteam0[p] = 'x';
             week[p] = 'x';
             return p;
           }

         }
  }


 if(tm1 == 1)
  {


    for(p = 7; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam1[p] == 'g')
           {
             teamvteam1[p] = 'x';
             week[p] = 'x';
             return p;
           }

         }
  }

   if(tm1 == 2)
  {


    for(p = 7; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam2[p] == 'g')
           {
             teamvteam2[p] = 'x';
             week[p] = 'x';
             return p;
           }

         }
  }


   if(tm1 == 3)
  {


    for(p = 7; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam3[p] == 'g')
           {
             teamvteam3[p] = 'x';
             week[p] = 'x';
             return p;
           }

         }
  }


   if(tm1 == 4)
  {


    for(p = 0; p < 8; p++)
         {
           if(week[p] == 'g' && teamvteam4[p] == 'g')
           {
             teamvteam4[p] = 'x';
             week[p] = 'x';
             return p;
           }

         }
  }

   if(tm1 == 5)
  {


    for(p = 0; p < 8; p++)
         {
           if(week[p] == 'g' && teamvteam5[p] == 'g')
           {
             teamvteam5[p] = 'x';
             week[p] = 'x';
             return p;
           }

         }
  }


   if(tm1 == 6)
  {


    for(p = 0; p < 8; p++)
         {
           if(week[p] == 'g' && teamvteam6[p] == 'g')
           {
             teamvteam6[p] = 'x';
             week[p] = 'x';
             return p;
           }

         }
  }

   if(tm1 == 7)
  {


    for(p = 0; p < 8; p++)
         {
           if(week[p] == 'g' && teamvteam7[p] == 'g')
           {
             teamvteam7[p] = 'x';
             week[p] = 'x';
             return p;
           }

         }
  }
  return 8;
}






int fixtureselite::checkturn()
{
  int p;
  int tm1;
  tm1 = 0;

  if(week[tm1] == 'g')
  {

    for(p = 7; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam0[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 7; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam1[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 7; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam2[p] == 'g' )
           {
             week[tm1] = 'x';
             return tm1;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 7; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam3[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {

    for(p = 0; p < 8; p++)
    {
        if(week[p] == 'g' && teamvteam4[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 8; p++)
    {
        if(week[p] == 'g' && teamvteam5[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 8; p++)
    {
        if(week[p] == 'g' && teamvteam6[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1;
           }
    }
  }

  tm1++;

   if(week[tm1] == 'g')
  {
    for(p = 0; p < 8; p++)
    {
        if(week[p] == 'g' && teamvteam7[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1;
           }
    }
  }




  return 8;
}








int fixtureselite::checkturntwo()
{
  int p;
  int tm1;
  tm1 = 7;

  if(week[tm1] == 'g')
  {

    for(p = 0; p < 8; p++)
    {
        if(week[p] == 'g' && teamvteam7[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 8; p++)
    {
        if(week[p] == 'g' && teamvteam6[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 8; p++)
    {
        if(week[p] == 'g' && teamvteam5[p] == 'g' )
           {
             week[tm1] = 'x';
             return tm1;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 8; p++)
    {
        if(week[p] == 'g' && teamvteam4[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {

    for(p = 7; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam3[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 7; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam2[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 7; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam1[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1;
           }
    }
  }

  tm1--;

   if(week[tm1] == 'g')
  {
    for(p = 7; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam0[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1;
           }
    }
  }



  return 8;
}

int fixtureselite::checkgamenumber()
{
   return gamenumber;
}

void fixtureselite::plusonegamenumber()
{
   gamenumber = gamenumber + 1;
}

void fixtureselite::turnplus()
{
    teamturn = teamturn + 1;
    if (teamturn >= 4)
    {
        teamturn = 0;
        strcpy(week,"gggggggg");
    }


}

void fixtureselite::fullseasononetwo()
{
    strcpy(week,"gggggggg");
    strcpy(teamvteam0,"xggggggg");
    strcpy(teamvteam1,"gxgggggg");
    strcpy(teamvteam2,"ggxggggg");
    strcpy(teamvteam3,"gggxgggg");
    strcpy(teamvteam4,"ggggxggg");
    strcpy(teamvteam5,"gggggxgg");
    strcpy(teamvteam6,"ggggggxg");
    strcpy(teamvteam7,"gggggggx");
}

void fixtureselite::startfullseasononetwo()
{
    teamturn = 0;
    gamenumber = 1;
    strcpy(week,"gggggggg");
    strcpy(teamvteam0,"xggggggg");
    strcpy(teamvteam1,"gxgggggg");
    strcpy(teamvteam2,"ggxggggg");
    strcpy(teamvteam3,"gggxgggg");
    strcpy(teamvteam4,"ggggxggg");
    strcpy(teamvteam5,"gggggxgg");
    strcpy(teamvteam6,"ggggggxg");
    strcpy(teamvteam7,"gggggggx");
}





void fixtureselite::save(fstream& op)
{
  op.write(week, sizeof(week));
  op.write(teamvteam0, sizeof(teamvteam0));
  op.write(teamvteam1, sizeof(teamvteam1));
  op.write(teamvteam2, sizeof(teamvteam2));
  op.write(teamvteam3, sizeof(teamvteam3));
  op.write(teamvteam4, sizeof(teamvteam4));
  op.write(teamvteam5, sizeof(teamvteam5));
  op.write(teamvteam6, sizeof(teamvteam6));
  op.write(teamvteam7, sizeof(teamvteam7));
  op.write((char *)&teamturn, sizeof(teamturn));
  op.write((char *)&gamenumber, sizeof(gamenumber));
}

int fixtureselite::load(fstream& ip)
{
  if(ip.eof())
  return 0;

  ip.read(week, sizeof(week));
  ip.read(teamvteam0, sizeof(teamvteam0));
  ip.read(teamvteam1, sizeof(teamvteam1));
  ip.read(teamvteam2, sizeof(teamvteam2));
  ip.read(teamvteam3, sizeof(teamvteam3));
  ip.read(teamvteam4, sizeof(teamvteam4));
  ip.read(teamvteam5, sizeof(teamvteam5));
  ip.read(teamvteam6, sizeof(teamvteam6));
  ip.read(teamvteam7, sizeof(teamvteam7));
  ip.read((char *)&teamturn, sizeof(teamturn));
  ip.read((char *)&gamenumber, sizeof(gamenumber));

  return 1;
}
