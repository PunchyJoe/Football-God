#include "footballgod.h"
#include "team.h"

team::team()
{
  order = 0;
  number = 0;
  division = 0;
  balance = 0;
  spent = 0;
  income = 0;
  capacity = 0;
  strcpy(name, " ");
  strcpy(stadium, " ");
  strcpy(region, " ");
  attack = 0;
  defence = 0;
  passing = 0;
  shooting = 0;
  played = 0;
  wins = 0;
  draws = 0;
  loses = 0;
  goalsfor = 0;
  goalsags = 0;
  gd = 0;
  points = 0;
}


team::~team()
{
}

void team::nameteamname(int n)
{

  int num;
  num = n;


  switch(num)
  {
  case 0:
  strcpy(name,"Dano City");
  strcpy(stadium,"Caesar Mount");
  strcpy(region,"South");
  order = 1;
  number = num;
  division = 1;
  capacity = 75000;
  break;
  case 1:
  strcpy(name,"Dano United");
  strcpy(stadium,"Metropolitis");
  strcpy(region,"South");
  order = 2;
  number = num;
  division = 1;
  capacity = 45000;
  break;
  case 2:
  strcpy(name,"Grawl Giants");
  strcpy(stadium,"Poseidonia");
  strcpy(region,"South");
  order = 3;
  number = num;
  division = 1;
  capacity = 30000;
  break;
  case 3:
  strcpy(name,"Shanda Celtic");
  strcpy(stadium,"Arcadia");
  strcpy(region,"North");
  order = 4;
  number = num;
  division = 1;
  capacity = 75000;
  break;
  case 4:
  strcpy(name,"Shanda Rangers");
  strcpy(stadium,"Urbanus");
  strcpy(region,"North");
  order = 5;
  number = num;
  division = 1;
  capacity = 55000;
  break;
  case 5:
  strcpy(name,"Shawford Rovers");
  strcpy(stadium,"Alexandra");
  strcpy(region,"North");
  order = 6;
  number = num;
  division = 1;
  capacity = 30000;
  break;
  case 6:
  strcpy(name,"Splands Astra");
  strcpy(stadium,"Nibiru");
  strcpy(region,"South");
  order = 7;
  number = num;
  division = 1;
  capacity = 30000;
  break;
  case 7:
  strcpy(name,"Xatraz");
  strcpy(stadium,"Maya");
  strcpy(region,"South");
  order = 8;
  number = num;
  division = 1;
  capacity = 35000;
  break;
  case 8:
  strcpy(name,"Boshanty Rift");
  strcpy(stadium,"Starlitum");
  strcpy(region,"North");
  order = 9;
  number = num;
  division = 2;
  capacity = 22000;
  break;
  case 9:
  strcpy(name,"Carlin North");
  strcpy(stadium,"Elmwood");
  strcpy(region,"North");
  order = 10;
  number = num;
  division = 2;
  capacity = 10000;
  break;
  case 10:
  strcpy(name,"Carlin South");
  strcpy(stadium,"Pegasus");
  strcpy(region,"South");
  order = 11;
  number = num;
  division = 2;
  capacity = 18000;
  break;
  case 11:
  strcpy(name,"Fubez Swashbucklers");
  strcpy(stadium,"Chichen Itza");
  strcpy(region,"North");
  order = 12;
  number = num;
  division = 2;
  capacity = 18000;
  break;
  case 12:
  strcpy(name,"Grawl Thunder");
  strcpy(stadium,"Ottoman");
  strcpy(region,"South");
  order = 13;
  number = num;
  division = 2;
  capacity = 25000;
  break;
  case 13:
  strcpy(name,"Griffin Albion");
  strcpy(stadium,"Underwood");
  strcpy(region,"South");
  order = 14;
  number = num;
  division = 2;
  capacity = 18000;
  break;
  case 14:
  strcpy(name,"Griffin Outback");
  strcpy(stadium,"Gobekli Tepe");
  strcpy(region,"South");
  order = 15;
  number = num;
  division = 2;
  capacity = 16000;
  break;
  case 15:
  strcpy(name,"Hilton Palace");
  strcpy(stadium,"Sumaria");
  strcpy(region,"South");
  order = 16;
  number = num;
  division = 2;
  capacity = 23000;
  break;
  case 16:
  strcpy(name,"Jolan County");
  strcpy(stadium,"Titan");
  strcpy(region,"South");
  order = 17;
  number = num;
  division = 2;
  capacity = 16000;
  break;
  case 17:
  strcpy(name,"Jolan Forest");
  strcpy(stadium,"Hyperion");
  strcpy(region,"South");
  order = 18;
  number = num;
  division = 2;
  capacity = 18000;
  break;
  case 18:
  strcpy(name,"Ozril Athletic");
  strcpy(stadium,"Welcome");
  strcpy(region,"North");
  order = 19;
  number = num;
  division = 2;
  capacity = 20000;
  break;
  case 19:
  strcpy(name,"Ozril Wanderers");
  strcpy(stadium,"Apollo");
  strcpy(region,"North");
  order = 20;
  number = num;
  division = 2;
  capacity = 22000;
  break;
  case 20:
  strcpy(name,"Ralin");
  strcpy(stadium,"Saxon");
  strcpy(region,"North");
  order = 21;
  number = num;
  division = 2;
  capacity = 12000;
  break;
  case 21:
  strcpy(name,"Splands Park Weald");
  strcpy(stadium,"Marduk");
  strcpy(region,"South");
  order = 22;
  number = num;
  division = 2;
  capacity = 25000;
  break;
  case 22:
  strcpy(name,"Totfield Tigers");
  strcpy(stadium,"Marcliffe");
  strcpy(region,"South");
  order = 23;
  number = num;
  division = 2;
  capacity = 10000;
  break;
  case 23:
  strcpy(name,"Woodlin");
  strcpy(stadium,"Dalcas");
  strcpy(region,"North");
  order = 24;
  number = num;
  division = 2;
  capacity = 10000;
  break;
  case 24:
  strcpy(name,"Arleng Swifts");
  strcpy(stadium,"Albatross");
  strcpy(region,"North");
  order = 25;
  number = num;
  division = 3;
  capacity = 8000;
  break;
  case 25:
  strcpy(name,"Drogo Saints");
  strcpy(stadium,"Polygon");
  strcpy(region,"South");
  order = 26;
  number = num;
  division = 3;
  capacity = 800;
  break;
  case 26:
  strcpy(name,"Ekus Town");
  strcpy(stadium,"Gambon Lane");
  strcpy(region,"South");
  order = 27;
  number = num;
  division = 3;
  capacity = 1500;
  break;
  case 27:
  strcpy(name,"Gregson Mills");
  strcpy(stadium,"Brahill Road");
  strcpy(region,"North");
  order = 28;
  number = num;
  division = 3;
  capacity = 1000;
  break;
  case 28:
  strcpy(name,"Lombarry Park");
  strcpy(stadium,"Leto");
  strcpy(region,"North");
  order = 29;
  number = num;
  division = 3;
  capacity = 4000;
  break;
  case 29:
  strcpy(name,"Lower Shawford");
  strcpy(stadium,"Crowcroft");
  strcpy(region,"North");
  order = 30;
  number = num;
  division = 3;
  capacity = 800;
  break;
  case 30:
  strcpy(name,"Mitz Hamlet");
  strcpy(stadium,"Municipal");
  strcpy(region,"South");
  order = 31;
  number = num;
  division = 3;
  capacity = 9000;
  break;
  case 31:
  strcpy(name,"Niak Tornadoes");
  strcpy(stadium,"Cofe Vault");
  strcpy(region,"North");
  order = 32;
  number = num;
  division = 3;
  capacity = 8500;
  break;
  case 32:
  strcpy(name,"Old Dano");
  strcpy(stadium,"Antiquitas");
  strcpy(region,"South");
  order = 33;
  number = num;
  division = 3;
  capacity = 2000;
  break;
  case 33:
  strcpy(name,"Pembrook Whittle");
  strcpy(stadium,"Fusion");
  strcpy(region,"North");
  order = 34;
  number = num;
  division = 3;
  capacity = 8500;
  break;
  case 34:
  strcpy(name,"Shinto Wilds");
  strcpy(stadium,"Smokey Bridge");
  strcpy(region,"North");
  order = 35;
  number = num;
  division = 3;
  capacity = 1000;
  break;
  case 35:
  strcpy(name,"Thicket Clay");
  strcpy(stadium,"Turnpike");
  strcpy(region,"North");
  order = 36;
  number = num;
  division = 3;
  capacity = 1800;
  break;
  case 36:
  strcpy(name,"Tige");
  strcpy(stadium,"The Den");
  strcpy(region,"South");
  order = 37;
  number = num;
  division = 3;
  capacity = 1100;
  break;
  case 37:
  strcpy(name,"Totfield Timberland");
  strcpy(stadium,"Slater Way");
  strcpy(region,"South");
  order = 38;
  number = num;
  division = 3;
  capacity = 900;
  break;
  case 38:
  strcpy(name,"Vorreta Burg");
  strcpy(stadium,"Sovereigns");
  strcpy(region,"North");
  order = 39;
  number = num;
  division = 3;
  capacity = 9000;
  break;
  case 39:
  strcpy(name,"Zeon Steeples");
  strcpy(stadium,"Northern Vale");
  strcpy(region,"North");
  order = 40;
  number = num;
  division = 3;
  capacity = 900;
  break;
  case 40:
  strcpy(name,"Tea");
  strcpy(stadium,"Tengentina");
  strcpy(region,"South");
  order = 41;
  number = num;
  division = 0;
  capacity = 800;
  break;
  case 41:
  strcpy(name,"Chazago");
  strcpy(stadium,"Life Sol");
  strcpy(region,"North");
  order = 42;
  number = num;
  division = 0;
  capacity = 800;
  break;
  default:
  break;
  }

}



void team::makenewteam(int n)
{
  int num;
  num = n;
  srand ( (unsigned int)time(NULL) );

  if(num >= 0 && num <= 7)
  {
   attack = rand() %  16 + 30;
   defence = rand() %  16 + 30;
   passing = rand() %  6 + 25;
   shooting = rand() %  6 + 25;
  }

  else if(num >= 8 && num <= 23)
  {
   attack = rand() %  16 + 20;
   defence = rand() % 16 + 20;
   passing = rand() % 6 + 15;
   shooting = rand() %  6 + 15;
  }

   else if(num >= 24 && num <= 39)
  {
   attack = rand() %  16 + 15;
   defence = rand() % 16 + 15;
   passing = rand() % 6 + 10;
   shooting = rand() %  6 + 10;
  }

  else
  {
   attack = 15;
   defence = 15;
   passing = 10;
   shooting = 10;
  }


}
void team::showteamsshow()
{
    cout << left << setw(20) << name << setw(3) << division << setw(8) << region << right
    << setw(10) << balance << right << setw(20) << stadium << right << setw(7) << capacity << right << endl;
}

void team::showteams()
{
    cout << left << setw(20) << name << right << setw(4) << played << right << setw(4) << wins << right << setw(4)
    << draws << right << setw(4) << loses << right << setw(6) << goalsfor << right << setw(6)<< goalsags << right << setw(6)<< gd
    << right << setw(6)<< points << endl;
}

void team::showendteams(fstream & filein)
{

    filein << left << setw(20) << name << right << setw(4) << played << right << setw(4) << wins << right << setw(4)
    << draws << right << setw(4) << loses << right << setw(6) << goalsfor << right << setw(6)<< goalsags << right << setw(6)<< gd
    << right << setw(6)<< points << endl;
}

void team::showfinance(fstream & filein)
{

    filein << right << setw(20) << name << "  Expenditure:"<< right << setw(12) << spent << "  Income:" << right << setw(12)<< income << "  Balance:" << right << setw(12) << balance << endl;
}

void team::resetstats()
{
      spent = 0;
      income = 0;
      played = 0;
      wins = 0;
      draws = 0;
      loses = 0;
      goalsfor = 0;
      goalsags = 0;
      gd = 0;
      points = 0;
}

void team::sortmoney(int syear)
{
    fstream notes;
    int dst;
    int improve;
    int addbalance;
    int testy;

    dst = syear;

    random_device generatormoney;
    uniform_int_distribution<int> money(1,10000000);


    notes.open("CLUBNOTES.txt",ios_base::app | ios_base::out);
        if(notes.fail())
        {
          cout << "Could not open Cup Results file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

   improve = rand() %  101;

   if(improve >= 51 && ((number >= 0 && number <= 3) || (number >= 8 && number <= 15) || (number >= 22 && number <= 23)|| (number >= 26 && number <= 31)))
    {
      addbalance = money(generatormoney);
      testy = addbalance / division;

      if(balance <= 2000000000)
      {
         balance = balance + testy;
         notes << dst << " " << name << " Deposit: +" << testy << endl;
      }
    }

    if(improve <= 50 && ((number >= 4 && number <= 7) || (number >= 16 && number <= 21) || (number >= 24 && number <= 25) || (number >= 32 && number <= 39)))
    {
      addbalance = money(generatormoney);
      testy = addbalance / division;
      balance = balance - testy;
      notes << dst << " " << name << " Debited: -" << testy << endl;
    }



   if(number >= 0 && number <= 3)
    {
        balance = balance + 10000000;
    }

    if(number == 7)
    {
        balance = balance - 5000000;
    }

    if(number >= 8 && number <= 15)
    {
        balance = balance + 5000000;
    }

    if(number >= 22 && number <= 23)
    {
        balance = balance - 1000000;
    }

    if(number >= 24 && number <= 31)
    {
        balance = balance + 1000000;
    }

    if(balance <= -100000000  && dst >= 3005)
    {
        attack = 15;
        defence = 15;
        passing = 10;
        shooting = 10;
        balance = 0;
        capacity = 800;
        notes << dst << " " << name << " is bankrupt" << endl;
   }

   notes.close();

}



void team::teamchanges(int syear)
{
  fstream notes;
  int improve;
  int weaken;
  int divo;
  int dst;

  dst = syear;

  srand ( (unsigned int)time(NULL) );

  notes.open("CLUBNOTES.txt",ios_base::app | ios_base::out);
        if(notes.fail())
        {
          cout << "Could not open Cup Results file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }



  if(dst >= 3004)
  {
  improve = rand() %  101;

  if(improve >= 95 && (number >= 0 && number <= 15))
  {
    if(balance < 50000000)
    {
       balance = 50000000;
    }

    if(capacity < 100000)
    {
       divo = capacity / 3;
       capacity = capacity + divo;
    }

    if(passing < 50)
    {
       passing = 50;
    }
    notes << dst << " " << name << " has expanded financially" << endl;
  }

  if(improve <= 5 && ((number >= 17 && number <= 21) || (number >= 24 && number <= 25)|| (number >= 33 && number <= 39)))
  {
    balance = -75000000;
    divo = capacity / 3;
    capacity = capacity - divo;
    passing = 25;
    notes << dst << " " << name << " has got into debt" << endl;
  }

  }


  if(division == 1)
  {
  improve = rand() %  2;

  if(shooting < 35 && balance > -10000000)
  {
   shooting = shooting + improve;
   balance = balance - (20000000 * improve);
   spent = spent - (20000000 * improve);
  }

   improve = rand() %  5;

  if(attack < 60 && balance > -10000000)
  {
   attack = attack + improve;
   balance = balance - (10000000 * improve);
   spent = spent - (10000000 * improve);
  }

  improve = rand() %  5;

  if(defence < 60 && balance > -10000000)
  {
  defence = defence + improve;
  balance = balance - (10000000 * improve);
  spent = spent - (10000000 * improve);
  }

  improve = rand() %  5;

  if(passing < 60 && balance > 0)
  {
   passing = passing + improve;
  }



  weaken = rand() %  2;

  if(balance < -30000000)
  {
   shooting = shooting - weaken;
   balance = balance + (10000000 * weaken);
   income = income + (10000000 * weaken);
  }

  weaken = rand() %  3;

  if(balance < 0)
  {
   attack = attack - weaken;
   balance = balance + (5000000 * weaken);
   income = income + (5000000 * weaken);
  }

  weaken = rand() %  3;

  if(balance < 0)
  {
  defence = defence - weaken;
  balance = balance + (5000000 * weaken);
  income = income + (5000000 * weaken);
  }

  weaken = rand() %  3;

  passing = passing - weaken;




 }

  else if(division == 2)
  {

  improve = rand() %  2;

  if(balance > 0)
  {
   shooting = shooting + improve;
   balance = balance - (800000 * improve);
   spent = spent - (800000 * improve);
  }

  improve = rand() % 4;

  if(balance > 0)
  {
   attack = attack + improve;
   balance = balance - (400000 * improve);
   spent = spent - (400000 * improve);
  }

  improve = rand() %  4;

  if(balance > 0)
  {
  defence = defence + improve;
  balance = balance - (400000 * improve);
  spent = spent - (400000 * improve);
  }

  improve = rand() %  4;

  if(balance > 0)
  {
   passing = passing + improve;
  }



   weaken = rand() %  2;

   shooting = shooting - weaken;
   balance = balance + (125000 * weaken);
   income = income + (125000 * weaken);

   weaken = rand() %  4;

   attack = attack - weaken;
   balance = balance + (25000 * weaken);
   income = income + (25000 * weaken);

   weaken = rand() %  4;

   defence = defence - weaken;
   balance = balance + (25000 * weaken);
   income = income + (25000 * weaken);


   weaken = rand() %  4;

   passing = passing - weaken;




 }


  else if(division == 3)
  {

  improve = rand() %  2;

  if(balance > 0)
  {
   shooting = shooting + improve;
   balance = balance - (200000 * improve);
   spent = spent - (200000 * improve);
  }

   improve = rand() % 3;

  if(balance > 0)
  {
   attack = attack + improve;
   balance = balance - (100000 * improve);
   spent = spent - (100000 * improve);
  }

  improve = rand() %  3;

  if(balance > 0)
  {
  defence = defence + improve;
  balance = balance - (100000 * improve);
  spent = spent - (100000 * improve);
  }

  improve = rand() %  3;

  if(balance > 0)
  {
   passing = passing + improve;
  }




   weaken = rand() %  2;

   shooting = shooting - weaken;
   balance = balance + (2000 * weaken);
   income = income + (2000 * weaken);


   weaken = rand() %  5;

   attack = attack - weaken;
   balance = balance + (1000 * weaken);
   income = income + (1000 * weaken);

   weaken = rand() %  5;

   defence = defence - weaken;
   balance = balance + (1000 * weaken);
   income = income + (1000 * weaken);

   weaken = rand() %  5;

   passing = passing - weaken;



 }

  else
  {
   attack = 15;
   defence = 15;
   passing = 10;
   shooting = 10;
   balance = 0;
  }



  if(shooting < 10)
  {
   shooting = 10;
  }

  if(attack < 15)
  {
   attack = 15;
  }

  if(defence < 15)
  {
  defence = 15;
  }

  if(passing < 10)
  {
   passing = 10;
  }

  notes.close();

}

void team::sackmanager(int syear)
{
  fstream notes;
  int improve;
  int devo;
  int dst;

  dst = syear;


  srand ( (unsigned int)time(NULL) );

  notes.open("CLUBNOTES.txt",ios_base::app | ios_base::out);
        if(notes.fail())
        {
          cout << "Could not open Cup Results file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }


  balance = balance - (70000000 / division);



   improve = rand() %  2;
   devo = rand() %  100;

  if(attack < 60 && devo < 50)
  {
   attack = attack + improve;
  }
  if(devo >= 50)
  {
   attack = attack - improve;
   if(attack < 0)
      attack = 0;
  }



   improve = rand() %  4;
   devo = rand() %  100;

  if(defence < 60 && devo < 50)
  {
   defence = defence + improve;
  }
  if(devo >= 50)
  {
   defence = defence - improve;
   if(defence < 0)
      defence = 0;
  }



   improve = rand() %  11;
   devo = rand() %  100;

  if(passing < 55 && devo < 50)
  {
   passing = passing + improve;
  }
  if(devo >= 50)
  {
   passing = passing - improve;
   if(passing < 0)
      passing = 0;
  }


  notes << dst << " Games played: " << played << "   " << name << " has got a new manger" << endl;

 notes.close();

}


void team::incapacity(int syear)
{
  fstream notes;
  int dst;

  dst = syear;

  notes.open("CLUBNOTES.txt",ios_base::app | ios_base::out);
        if(notes.fail())
        {
          cout << "Could not open Cup Results file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

   balance = balance - 5000000;
   capacity = capacity + 1000;
   notes << dst << " " << name << " has increased seating capacity by 1000" << endl;

   notes.close();

}


void team::intocredit(int syear)
{
    fstream notes;

    int dst, creds, divo;

    dst = syear;

    random_device generatormoney;
    uniform_int_distribution<int> money(1,50000000);

     notes.open("CLUBNOTES.txt",ios_base::app | ios_base::out);
        if(notes.fail())
        {
          cout << "Could not open Cup Results file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

    creds = money(generatormoney);


    balance = balance + creds;


    if(capacity < 100000)
    {
       divo = capacity / 3;
       capacity = capacity + divo;
    }

    if(passing < 50)
    {
       passing = 50;
    }
    notes << dst << " " << name << " has expanded financially" << endl;

    notes.close();
 }



void team::intodebit(int syear)
{
    fstream notes;

    int dst, creds, divo;

    dst = syear;

    random_device generatormoney;
    uniform_int_distribution<int> money(1,50000000);

     notes.open("CLUBNOTES.txt",ios_base::app | ios_base::out);
        if(notes.fail())
        {
          cout << "Could not open Cup Results file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

    creds = money(generatormoney);

    balance = balance - creds;

    divo = capacity / 3;
    capacity = capacity - divo;

    passing = 25;

    notes << dst << " " << name << " has got into debt" << endl;

    notes.close();
}







int team::sellsellsell(int syear)
{
  fstream notes;
  int dst;
  int purse = 0;
  int weaken;

  dst = syear;

  srand ( (unsigned int)time(NULL) );

  notes.open("CLUBNOTES.txt",ios_base::app | ios_base::out);
        if(notes.fail())
        {
          cout << "Could not open Cup Results file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

 if(division == 1)
 {

   if(shooting > 12)
   {
      weaken = rand() %  2;
      shooting = shooting - weaken;
      balance = balance + (8000000 * weaken);
      purse = purse + (8000000 * weaken);
   }

  if(attack > 18)
  {
     weaken = rand() %  3;
     attack = attack - weaken;
     balance = balance + (3000000 * weaken);
     purse = purse + (3000000 * weaken);
  }


  if(defence > 18)
  {
     weaken = rand() %  3;
     defence = defence - weaken;
     balance = balance + (3000000 * weaken);
     purse = purse + (3000000 * weaken);
  }

  if(passing > 13)
  {
     weaken = rand() %  3;
     passing = passing - weaken;
  }

}

 if(division == 2)
  {

   if(shooting > 12)
   {
      weaken = rand() %  2;
      shooting = shooting - weaken;
      balance = balance + (100000 * weaken);
      purse = purse + (100000 * weaken);
   }

  if(attack > 18)
  {
     weaken = rand() %  3;
     attack = attack - weaken;
     balance = balance + (20000 * weaken);
     purse = purse + (20000 * weaken);
  }


  if(defence > 18)
  {
     weaken = rand() %  3;
     defence = defence - weaken;
     balance = balance + (20000 * weaken);
     purse = purse + (20000 * weaken);
  }

  if(passing > 13)
  {
     weaken = rand() %  3;
     passing = passing - weaken;
  }

 }

 if(division == 3)
 {

   if(shooting > 12)
   {
      weaken = rand() %  2;
      shooting = shooting - weaken;
      balance = balance + (1800 * weaken);
      purse = purse + (1800 * weaken);
   }

  if(attack > 18)
  {
     weaken = rand() %  3;
     attack = attack - weaken;
     balance = balance + (800 * weaken);
     purse = purse + (800 * weaken);
  }


  if(defence > 18)
  {
     weaken = rand() %  3;
     defence = defence - weaken;
     balance = balance + (800 * weaken);
     purse = purse + (800 * weaken);
  }

  if(passing > 13)
  {
     weaken = rand() %  3;
     passing = passing - weaken;
  }

 }
  notes << dst << " " << name << " Has sold assets worth: " << purse <<  endl;
  notes.close();

  return purse;

}

void team::promo(int swhat)
{
    int cgs;
    cgs = swhat;

    if(cgs == 1)
    {
      if(attack < 30)
      {
         attack = 30;
      }
      if(defence < 30)
      {
         defence = 30;
      }
      if(passing < 25)
      {
         passing = 25;
      }
      if(shooting < 25)
      {
         shooting = 25;
      }
    }

    if(cgs == 2)
    {
      if(attack > 35)
      {
         attack = 35;
      }
      if(defence > 35)
      {
         defence = 35;
      }
      if(passing > 20)
      {
         passing = 20;
      }
      if(shooting > 20)
      {
         shooting = 20;
      }
    }


    if(cgs == 3)
    {
      if(attack < 20)
      {
         attack = 20;
      }
      if(defence < 20)
      {
         defence = 20;
      }
      if(passing < 15)
      {
         passing = 15;
      }
      if(shooting < 15)
      {
         shooting = 15;
      }
    }

    if(cgs == 4)
    {
      if(attack > 25)
      {
         attack = 25;
      }
      if(defence > 25)
      {
         defence = 25;
      }
      if(passing > 15)
      {
         passing = 15;
      }
      if(shooting > 15)
      {
         shooting = 15;
      }
    }



}

void team::givepoints(int gip)
{
    points = points + gip;
}

int team::attackshow()
{
    return attack;
}

int team::defenceshow()
{
    return defence;
}

int team::passingshow()
{
    return passing;
}

int team::ordershow()
{
    return order;
}

int team::numbershow()
{
    return number;
}
int team::shootingshow()
{
    return shooting;
}

int team::capacityshow()
{
    return capacity;
}

int team::balanceshow()
{
    return balance;
}

void team::teamshow(char *mn)
{
    memcpy(mn,name,80);
}

void team::stadiumshow(char *mn)
{
    memcpy(mn,stadium,80);
}

void team::regionshow(char *mn)
{
    memcpy(mn,region,10);
}

int team::showdivision()
{
    return division;
}

int team::showplayed()
{
    return played;
}

int team::showwins()
{
    return wins;
}

int team::showdraws()
{
    return draws;
}

int team::showloses()
{
    return loses;
}

int team::showgoalsfor()
{
    return goalsfor;
}

int team::showgoalsags()
{
    return goalsags;
}

int team::showgoaldiff()
{

    return gd;
}


void team::changegoaldiff()
{
    gd = goalsfor - goalsags;
}

int team::showpoints()
{
    return points;
}

void team::changeplayed()
{
    played = played + 1;
}

void team::changewindrawloss(int cs)
{
    if(cs == 1)
        wins = wins + 1;
    if(cs == 2)
        draws = draws + 1;
    if(cs == 3)
        loses = loses + 1;
}

void team::changegoalsfor(int cs)
{
    goalsfor = goalsfor + cs;
}

void team::changegoalsags(int cs)
{
    goalsags = goalsags + cs;
}

void team::changebalance(int cs)
{
    balance = balance + cs;
}

void team::changenumber(int zz)
{
    number = zz;
}

void team::swapshowteam(const char *mn, const char *sn, const char *rn, int pdd, int a, int rt, int brt)
{
    memcpy(name,mn,80);
    memcpy(stadium,sn,80);
    memcpy(region,rn,10);
    order = pdd;
    balance = a;
    capacity = rt;
    division = brt;
}

void team::swapteam(const char *mn, int pdd, int a, int rt, int brt, int gsf, int gsa, int gddd, int ppp)
{
    memcpy(name,mn,80);
    played = pdd;
    wins = a;
    draws = rt;
    loses = brt;
    goalsfor = gsf;
    goalsags = gsa;
    gd = gddd;
    points = ppp;
}

void team::swapteampos(const char *mn, int pdd, int gsf, int gsa, int gddd, int ppp)
{
    memcpy(name,mn,80);
    order = pdd;
    goalsfor = gsf;
    goalsags = gsa;
    gd = gddd;
    points = ppp;
}

void team::swapteampromo(const char *mn, const char *sn, const char *rn, int pdd, int a, int rt, int brt, int gsf, int gsa, int gddd, int ppp, int ogg, int tatt, int tdef, int tpass, int tshoot, int capt, int balt)
{
    memcpy(name,mn,80);
    memcpy(stadium,sn,80);
    memcpy(region,rn,10);
    played = pdd;
    wins = a;
    draws = rt;
    loses = brt;
    goalsfor = gsf;
    goalsags = gsa;
    gd = gddd;
    points = ppp;
    order = ogg;
    attack = tatt;
    defence = tdef;
    passing = tpass;
    shooting = tshoot;
    capacity = capt;
    balance = balt;
}

void team::save(fstream& op)
{
  op.write((char *)&order, sizeof(order));
  op.write((char *)&number, sizeof(number));
  op.write((char *)&division, sizeof(division));
  op.write((char *)&balance, sizeof(balance));
  op.write((char *)&spent, sizeof(spent));
  op.write((char *)&income, sizeof(income));
  op.write((char *)&capacity, sizeof(capacity));
  op.write(name, sizeof(name));
  op.write(stadium, sizeof(stadium));
  op.write(region, sizeof(region));
  op.write((char *)&attack, sizeof(attack));
  op.write((char *)&defence, sizeof(defence));
  op.write((char *)&passing, sizeof(passing));
  op.write((char *)&shooting, sizeof(shooting));
  op.write((char *)&played, sizeof(played));
  op.write((char *)&wins, sizeof(wins));
  op.write((char *)&draws, sizeof(draws));
  op.write((char *)&loses, sizeof(loses));
  op.write((char *)&goalsfor, sizeof(goalsfor));
  op.write((char *)&goalsags, sizeof(goalsags));
  op.write((char *)&gd, sizeof(gd));
  op.write((char *)&points, sizeof(points));
}




int team::load(fstream& ip)
{
  if(ip.eof())
  return 0;

  ip.read((char *)&order, sizeof(order));
  ip.read((char *)&number, sizeof(number));
  ip.read((char *)&division, sizeof(division));
  ip.read((char *)&balance, sizeof(balance));
  ip.read((char *)&spent, sizeof(spent));
  ip.read((char *)&income, sizeof(income));
  ip.read((char *)&capacity, sizeof(capacity));
  ip.read(name, sizeof(name));
  ip.read(stadium, sizeof(stadium));
  ip.read(region, sizeof(region));
  ip.read((char *)&attack, sizeof(attack));
  ip.read((char *)&defence, sizeof(defence));
  ip.read((char *)&passing, sizeof(passing));
  ip.read((char *)&shooting, sizeof(shooting));
  ip.read((char *)&played, sizeof(played));
  ip.read((char *)&wins, sizeof(wins));
  ip.read((char *)&draws, sizeof(draws));
  ip.read((char *)&loses, sizeof(loses));
  ip.read((char *)&goalsfor, sizeof(goalsfor));
  ip.read((char *)&goalsags, sizeof(goalsags));
  ip.read((char *)&gd, sizeof(gd));
  ip.read((char *)&points, sizeof(points));
  return 1;
}
