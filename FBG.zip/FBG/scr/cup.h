#ifndef CUP_H_INCLUDED
#define CUP_H_INCLUDED
#include <fstream>

using namespace std;

class cup
{

   char cupteams[41];
   int gamenumber;

    public:
    cup();
    ~cup();

    int roundchecker();
    int teamchecker(int tm,int tcl);
    void teamwonlost(int tm,int tcl);
    void resetcup();
    int showgamenumber();
    void gamenumberplusone();
    void resetgamenumber();


    void save(fstream& op);
    int load(fstream& ip);
};

#endif // CUP_H_INCLUDED
