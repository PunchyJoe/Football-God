#include "footballgod.h"

int leagueposition(int ddd,int ttt);

void belitegame(void)
{


  fstream gm;
  fstream fx;
  fstream becm;

  int shoot1, shoot2, ver, p;
  int ok1, tp1, at1, df1, ps1;
  int ok2, tp2, at2, df2, ps2;
  int pl1, pl2, lg1, lg2;
  int bub, bigadvantage, cs1, cs2;
  int at0, df0, ps0;
  int at4, df4, ps4;
  int ht1 = 0;
  int ht2 = 0;
  int totalattack1, totaldefence1, totalpassing1;
  int totalattack2, totaldefence2, totalpassing2;
  int shotsongoal1, shotsongoal2;
  int llgames, posesion1, posesion2, homeadvantage;
  char team1[80];
  char team2[80];
  char stadium[80];


  fixtureselite fixes;

  srand ( (unsigned int)time(NULL) );







    fx.open("ELITEFIXTURES.BIN",ios_base::binary|ios_base::in);
        if(fx.fail())
        {
          cout << "Could not open teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

     fixes.load(fx);


     fx.close();




      bub = fixes.checkgamenumber();


      if(bub >= 113)
      {
        return;
      }






  gm.open("TEAMS.BIN",ios_base::binary|ios_base::in);
        if(gm.fail())
        {
          cout << "Could not open teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

  team* igm = new team[NUM_OF_TEAMS_TOTAL];

 //vector<team> igm (NUM_OF_TEAMS_TOTAL);

  for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
  {
      igm[p].load(gm);
  }

    gm.close();




  llgames = igm[8].showplayed();




   if(llgames > 7)
   {




       if ((bub >= 1 && bub <= 4) || (bub >= 9 && bub <= 12) || (bub >= 17 && bub <= 20) || (bub >= 25 && bub <= 28)
           || (bub >= 33 && bub <= 36) || (bub >= 41 && bub <= 44) || (bub >= 49 && bub <= 52)
           || (bub >= 58 && bub <= 60) || (bub >= 65 && bub <= 68) || (bub >= 73 && bub <= 76)
           || (bub >= 81 && bub <= 84) || (bub >= 89 && bub <= 92) || (bub >= 97 && bub <= 100)
           || (bub >= 105 && bub <= 108))
       {
           tp1 = fixes.checkturn();
           ok1 = fixes.teamchecker(tp1);
       }

       else if (bub == 57)
       {
           fixes.fullseasononetwo();
           tp1 = fixes.checkturn();
           ok1 = fixes.teamchecker(tp1);
       }

       else
       {
           tp1 = fixes.checkturntwo();
           ok1 = fixes.teamchecker(tp1);

       }



        becm.open("ELITERESULTS.txt",ios_base::app | ios_base::out);
        if(becm.fail())
        {
          cout << "Could not open Records file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }






      if(ok1 >= 8)
      {
       cout << "Union Elte season over - All matches played id:8" << endl;
       chrono::seconds dura(1);
       this_thread::sleep_for(dura);
       return;
      }





         igm[tp1].teamshow(team1);
         igm[ok1].teamshow(team2);
         igm[tp1].stadiumshow(stadium);
         pl1  = igm[tp1].ordershow();
         pl2  = igm[ok1].ordershow();
         at1 = igm[tp1].attackshow();
         at2 = igm[ok1].attackshow();
         df1 = igm[tp1].defenceshow();
         df2 = igm[ok1].defenceshow();
         ps1 = igm[tp1].passingshow();
         ps2 = igm[ok1].passingshow();
         shoot1 = igm[tp1].shootingshow();
         shoot2 = igm[ok1].shootingshow();
         cs1 = igm[tp1].capacityshow();
         cs2 = igm[ok1].capacityshow();

         lg1 = leagueposition(1,pl1);
         lg2 = leagueposition(1,pl2);


       cout << endl << endl << "UNION ELITE   " << team1 << "(" << lg1 << ")" << "  VS  " << team2 << "(" << lg2 << ")  at: " << stadium << "  cap:" << cs1 << endl;
       cout << endl << endl;
       chrono::seconds dura(5);
       this_thread::sleep_for(dura);



       tp2 = 0;
       ok2 = 0;
       shotsongoal1 = 0;
       shotsongoal2 = 0;
       posesion1 = 0;
       posesion2 = 0;


       if (cs1 > cs2)
       {
          bigadvantage = (cs1 - cs2) / SUPERIORITY;
          ps1 = ps1 + bigadvantage;
       }

       if (cs2 > cs1)
       {
          bigadvantage = (cs2 - cs1) / SUPERIORITY;
          ps2 = ps2 + bigadvantage;
       }




        for(p = 0; p < 90; p++)
        {

      homeadvantage = rand() % 11 + 2;
      at0 = rand() % 151;
      df0 = rand() % 101 + 100;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + 100;
      ps4 = rand() % 151;



      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;

      totalpassing1 = totalpassing1 + homeadvantage;
      ver = rand() % 101;





     if(totalpassing1 >= totalpassing2)
      {
          posesion1 = posesion1 + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1 = shotsongoal1 + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             }
          }
        }
      }



       if(totalpassing2 > totalpassing1)
      {
          posesion2 = posesion2 + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2 = shotsongoal2 + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             }
          }
        }
      }
      if(p == 45)
       {
          ht1 = tp2;
          ht2 = ok2;
       }
  }



         cout << endl << endl << "             FINAL RESULT" << endl;
         cout << endl << endl << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;

         becm << right << setw(20) << team1 << " " << tp2 << right << setw(20) << team2 << " " << ok2 << "  HT:" << ht1 << "-" << ht2 << right << setw(20) << "SHOTS ON GOAL: "
         << right << setw(4) << shotsongoal1 << "   - " << right << setw(4) << shotsongoal2 << right << setw(20) << "POSSESION: "
         << right << setw(4) << posesion1 << "   - " << right << setw(4) << posesion2 << endl;



        igm[tp1].changeplayed();
        igm[ok1].changeplayed();
        igm[tp1].changegoalsfor(tp2);
        igm[ok1].changegoalsfor(ok2);
        igm[tp1].changegoalsags(ok2);
        igm[ok1].changegoalsags(tp2);
        igm[tp1].changegoaldiff();
        igm[ok1].changegoaldiff();

        if(tp2 > ok2)
        {
            igm[tp1].givepoints(3);
            igm[tp1].changewindrawloss(1);
            igm[ok1].changewindrawloss(3);

        }
        if(tp2 < ok2)
        {

           igm[ok1].givepoints(3);
           igm[tp1].changewindrawloss(3);
           igm[ok1].changewindrawloss(1);
        }

        if(tp2 == ok2)
        {
           igm[tp1].givepoints(1);
           igm[ok1].givepoints(1);
           igm[tp1].changewindrawloss(2);
           igm[ok1].changewindrawloss(2);
        }

        igm[tp1].changebalance(cs1 * 10);
        igm[ok1].changebalance(cs1 * 3);




    gm.open("TEAMS.BIN",ios_base::binary|ios_base::out);
        if(gm.fail())
        {
          cout << "Could not open teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }


        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
        {
          igm[p].save(gm);
        }


      gm.close();

      lg1 = leagueposition(1,pl1);
      lg2 = leagueposition(1,pl2);

      cout << "        " << lg1 << "  League Position  " << lg2 << endl;
      cout << "  HT:" << ht1 << "-" << ht2 << "  SHOTS ON GOAL: " << shotsongoal1 << "-" << shotsongoal2 << right << "  POSSESION: " << posesion1 << "-" << posesion2 << endl << endl;

      this_thread::sleep_for(dura);

       fixes.turnplus();

       fixes.plusonegamenumber();

       fx.open("ELITEFIXTURES.BIN",ios_base::binary|ios_base::out);
        if(fx.fail())
        {
          cout << "Could not open fixtures file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

       fixes.save(fx);

   }

       delete [] igm;

//       igm = nullptr;

       fx.close();

       becm.close();



      chrono::seconds dura(5);

      this_thread::sleep_for(dura);

    return;
}
