#include "footballgod.h"
#include "fixtures2.h"




fixturesconone::fixturesconone()
{
   teamturn = 0;
   gamenumber = 1;
   strcpy(week,"gggggggggggggggg");
   strcpy(teamvteam8,"xggggggggggggggg");
   strcpy(teamvteam9,"gxgggggggggggggg");
   strcpy(teamvteam10,"ggxggggggggggggg");
   strcpy(teamvteam11,"gggxgggggggggggg");
   strcpy(teamvteam12,"ggggxggggggggggg");
   strcpy(teamvteam13,"gggggxgggggggggg");
   strcpy(teamvteam14,"ggggggxggggggggg");
   strcpy(teamvteam15,"gggggggxgggggggg");
   strcpy(teamvteam16,"ggggggggxggggggg");
   strcpy(teamvteam17,"gggggggggxgggggg");
   strcpy(teamvteam18,"ggggggggggxggggg");
   strcpy(teamvteam19,"gggggggggggxgggg");
   strcpy(teamvteam20,"ggggggggggggxggg");
   strcpy(teamvteam21,"gggggggggggggxgg");
   strcpy(teamvteam22,"ggggggggggggggxg");
   strcpy(teamvteam23,"gggggggggggggggx");

}


fixturesconone::~fixturesconone()
{
}



int fixturesconone::teamchecker(int tc1)
{
  int tm1;
  tm1 = tc1;
  int p;

  if(tm1 == 8)
  {


    for(p = 15; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam8[p] == 'g')
           {
             teamvteam8[p] = 'x';
             week[p] = 'x';
             return p + 8;
           }

         }
  }


 if(tm1 == 9)
  {


    for(p = 15; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam9[p] == 'g')
           {
             teamvteam9[p] = 'x';
             week[p] = 'x';
             return p + 8;
           }

         }
  }

   if(tm1 == 10)
  {


    for(p = 15; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam10[p] == 'g')
           {
             teamvteam10[p] = 'x';
             week[p] = 'x';
             return p + 8;
           }

         }
  }


   if(tm1 == 11)
  {


    for(p = 15; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam11[p] == 'g')
           {
             teamvteam11[p] = 'x';
             week[p] = 'x';
             return p + 8;
           }

         }
  }


   if(tm1 == 12)
  {


    for(p = 15; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam12[p] == 'g')
           {
             teamvteam12[p] = 'x';
             week[p] = 'x';
             return p + 8;
           }

         }
  }

   if(tm1 == 13)
  {


    for(p = 15; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam13[p] == 'g')
           {
             teamvteam13[p] = 'x';
             week[p] = 'x';
             return p + 8;
           }

         }
  }


   if(tm1 == 14)
  {


    for(p = 15; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam14[p] == 'g')
           {
             teamvteam14[p] = 'x';
             week[p] = 'x';
             return p + 8;
           }

         }
  }

   if(tm1 == 15)
  {


    for(p = 15; p >= 0; p--)
         {
           if(week[p] == 'g' && teamvteam15[p] == 'g')
           {
             teamvteam15[p] = 'x';
             week[p] = 'x';
             return p + 8;
           }

         }
  }

  if(tm1 == 16)
  {


    for(p = 0; p < 16; p++)
         {
           if(week[p] == 'g' && teamvteam16[p] == 'g')
           {
             teamvteam16[p] = 'x';
             week[p] = 'x';
             return p + 8;
           }

         }
  }

  if(tm1 == 17)
  {


    for(p = 0; p < 16; p++)
         {
           if(week[p] == 'g' && teamvteam17[p] == 'g')
           {
             teamvteam17[p] = 'x';
             week[p] = 'x';
             return p + 8;
           }

         }
  }

  if(tm1 == 18)
  {


    for(p = 0; p < 16; p++)
         {
           if(week[p] == 'g' && teamvteam18[p] == 'g')
           {
             teamvteam18[p] = 'x';
             week[p] = 'x';
             return p + 8;
           }

         }
  }

  if(tm1 == 19)
  {


    for(p = 0; p < 16; p++)
         {
           if(week[p] == 'g' && teamvteam19[p] == 'g')
           {
             teamvteam19[p] = 'x';
             week[p] = 'x';
             return p + 8;
           }

         }
  }

  if(tm1 == 20)
  {


    for(p = 0; p < 16; p++)
         {
           if(week[p] == 'g' && teamvteam20[p] == 'g')
           {
             teamvteam20[p] = 'x';
             week[p] = 'x';
             return p + 8;
           }

         }
  }

  if(tm1 == 21)
  {


    for(p = 0; p < 16; p++)
         {
           if(week[p] == 'g' && teamvteam21[p] == 'g')
           {
             teamvteam21[p] = 'x';
             week[p] = 'x';
             return p + 8;
           }

         }
  }

  if(tm1 == 22)
  {


    for(p = 0; p < 16; p++)
         {
           if(week[p] == 'g' && teamvteam22[p] == 'g')
           {
             teamvteam22[p] = 'x';
             week[p] = 'x';
             return p + 8;
           }

         }
  }

  if(tm1 == 23)
  {


    for(p = 0; p < 16; p++)
         {
           if(week[p] == 'g' && teamvteam23[p] == 'g')
           {
             teamvteam23[p] = 'x';
             week[p] = 'x';
             return p + 8;
           }

         }
  }


  return 24;
}


int fixturesconone::checkgamenumber()
{
   return gamenumber;
}

void fixturesconone::plusonegamenumber()
{
   gamenumber = gamenumber + 1;
}



void fixturesconone::turnplus()
{
     teamturn = teamturn + 1;
    if (teamturn >= 8)
    {
        teamturn = 0;
        strcpy(week,"gggggggggggggggg");
    }

}


int fixturesconone::checkturn()
{
  int p;
  int tm1;
  tm1 = 0;


  if(week[tm1] == 'g')
  {
   for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam8[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam9[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam10[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam11[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
   for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam12[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam13[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam14[p] == 'g')
           {
            week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam15[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam16[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam17[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam18[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
   for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam19[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam20[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam21[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam22[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1++;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam23[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }


  return 24;
}











int fixturesconone::checkturntwo()
{
  int p;
  int tm1;
  tm1 = 15;


  if(week[tm1] == 'g')
  {
   for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam23[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam22[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam21[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam20[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
   for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam19[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam18[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam17[p] == 'g')
           {
            week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 0; p < 16; p++)
    {
        if(week[p] == 'g' && teamvteam16[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam15[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam14[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam13[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
   for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam12[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam11[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam10[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam9[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }

  tm1--;

  if(week[tm1] == 'g')
  {
    for(p = 15; p >= 0; p--)
    {
        if(week[p] == 'g' && teamvteam8[p] == 'g')
           {
             week[tm1] = 'x';
             return tm1 + 8;
           }
    }
  }


  return 24;
}


void fixturesconone::fullseasontwo()
{
   teamturn = 0;
   gamenumber = 1;
   strcpy(week,"gggggggggggggggg");
   strcpy(teamvteam8,"xggggggggggggggg");
   strcpy(teamvteam9,"gxgggggggggggggg");
   strcpy(teamvteam10,"ggxggggggggggggg");
   strcpy(teamvteam11,"gggxgggggggggggg");
   strcpy(teamvteam12,"ggggxggggggggggg");
   strcpy(teamvteam13,"gggggxgggggggggg");
   strcpy(teamvteam14,"ggggggxggggggggg");
   strcpy(teamvteam15,"gggggggxgggggggg");
   strcpy(teamvteam16,"ggggggggxggggggg");
   strcpy(teamvteam17,"gggggggggxgggggg");
   strcpy(teamvteam18,"ggggggggggxggggg");
   strcpy(teamvteam19,"gggggggggggxgggg");
   strcpy(teamvteam20,"ggggggggggggxggg");
   strcpy(teamvteam21,"gggggggggggggxgg");
   strcpy(teamvteam22,"ggggggggggggggxg");
   strcpy(teamvteam23,"gggggggggggggggx");
}



void fixturesconone::save(fstream& op)
{
  op.write(week, sizeof(week));
  op.write(teamvteam8, sizeof(teamvteam8));
  op.write(teamvteam9, sizeof(teamvteam9));
  op.write(teamvteam10, sizeof(teamvteam10));
  op.write(teamvteam11, sizeof(teamvteam11));
  op.write(teamvteam12, sizeof(teamvteam12));
  op.write(teamvteam13, sizeof(teamvteam13));
  op.write(teamvteam14, sizeof(teamvteam14));
  op.write(teamvteam15, sizeof(teamvteam15));
  op.write(teamvteam16, sizeof(teamvteam16));
  op.write(teamvteam17, sizeof(teamvteam17));
  op.write(teamvteam18, sizeof(teamvteam18));
  op.write(teamvteam19, sizeof(teamvteam19));
  op.write(teamvteam20, sizeof(teamvteam20));
  op.write(teamvteam21, sizeof(teamvteam21));
  op.write(teamvteam22, sizeof(teamvteam22));
  op.write(teamvteam23, sizeof(teamvteam23));
  op.write((char *)&teamturn, sizeof(teamturn));
  op.write((char *)&gamenumber, sizeof(gamenumber));
}

int fixturesconone::load(fstream& ip)
{
  if(ip.eof())
  return 0;

  ip.read(week, sizeof(week));
  ip.read(teamvteam8, sizeof(teamvteam8));
  ip.read(teamvteam9, sizeof(teamvteam9));
  ip.read(teamvteam10, sizeof(teamvteam10));
  ip.read(teamvteam11, sizeof(teamvteam11));
  ip.read(teamvteam12, sizeof(teamvteam12));
  ip.read(teamvteam13, sizeof(teamvteam13));
  ip.read(teamvteam14, sizeof(teamvteam14));
  ip.read(teamvteam15, sizeof(teamvteam15));
  ip.read(teamvteam16, sizeof(teamvteam16));
  ip.read(teamvteam17, sizeof(teamvteam17));
  ip.read(teamvteam18, sizeof(teamvteam18));
  ip.read(teamvteam19, sizeof(teamvteam19));
  ip.read(teamvteam20, sizeof(teamvteam20));
  ip.read(teamvteam21, sizeof(teamvteam21));
  ip.read(teamvteam22, sizeof(teamvteam22));
  ip.read(teamvteam23, sizeof(teamvteam23));
  ip.read((char *)&teamturn, sizeof(teamturn));
  ip.read((char *)&gamenumber, sizeof(gamenumber));

  return 1;
}
