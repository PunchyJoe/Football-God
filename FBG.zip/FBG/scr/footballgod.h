#include "team.h"
#include "fixtureselite.h"
#include "fixtures2.h"
#include "fixtures3.h"
#include "cup.h"
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <fstream>
#include <string>
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <chrono>
#include <thread>
#include <iomanip>
#include <stdexcept>
#include <memory>
#include <vector>
#include <type_traits>
#include <random>
#include <Windows.h>


using namespace std;

const int NUM_OF_TEAMS_LOWER = 17;
const int NUM_OF_TEAMS_TOTAL = 42;
const int SUPERIORITY = 1500;
const int SUPERIORITY_LOWER = 525;
const int SUPERIORITY_LOWER_LOWER = 260;
const int CUPSUPERIORITY = 2000;

