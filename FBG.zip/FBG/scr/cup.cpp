#include "footballgod.h"
#include "cup.h"



cup::cup()
{

   strcpy(cupteams,"3333333311111111111111111111111111111111");
   gamenumber = 1;
}


cup::~cup()
{
}
int cup::roundchecker()
{
  int p;


  for(p = 8; p < 40; p++)
  {
       if(cupteams[p] == '1')
       {
         return 1;
       }
  }
 for(p = 8; p < 40; p++)
  {
       if(cupteams[p] == '2')
       {
         return 2;
       }
  }
 for(p = 0; p < 40; p++)
  {
       if(cupteams[p] == '3')
       {
         return 3;
       }
  }
  for(p = 0; p < 40; p++)
  {
       if(cupteams[p] == '4')
       {
         return 4;
       }
  }
 for(p = 0; p < 40; p++)
  {
       if(cupteams[p] == '5')
       {
         return 5;
       }
  }
 for(p = 0; p < 40; p++)
  {
       if(cupteams[p] == '6')
       {
         return 6;
       }
  }

  return 7;
}

int cup::teamchecker(int tm, int tcl)
{
  int ttt;
  int tm1;

  ttt = tm;
  tm1 = tcl;


   if(tm1 == 1)
    {
     if(cupteams[ttt] == '1')
       {
        return ttt;
       }
     else
       {
       return 100;
       }
     }

   else if(tm1 == 2)
    {
     if(cupteams[ttt] == '2')
       {
        return ttt;
       }
     else
       {
       return 100;
       }
     }

   else if(tm1 == 3)
    {
     if(cupteams[ttt] == '3')
       {
        return ttt;
       }
     else
       {
       return 100;
       }
     }

    else if(tm1 == 4)
    {
     if(cupteams[ttt] == '4')
       {
        return ttt;
       }
     else
       {
       return 100;
       }
     }

    else if(tm1 == 5)
    {
     if(cupteams[ttt] == '5')
       {
        return ttt;
       }
     else
       {
       return 100;
       }
     }

    else if(tm1 == 6)
    {
     if(cupteams[ttt] == '6')
       {
        return ttt;
       }
     else
       {
       return 100;
       }
     }

     else
        {
           return 100;
        }

}

void cup::teamwonlost(int tm,int tcl)
{
  int tm1;
  int ttt;
  ttt = tm;
  tm1 = tcl;

  if(tm1 == 0)
  {
   cupteams[ttt] = '0';
  }

  else if(tm1 == 2)
  {
   cupteams[ttt] = '2';
  }

  else if(tm1 == 3)
  {
   cupteams[ttt] = '3';
  }

  else if(tm1 == 4)
  {
   cupteams[ttt] = '4';
  }

  else if(tm1 == 5)
  {
   cupteams[ttt] = '5';
  }

  else if(tm1 == 6)
  {
   cupteams[ttt] = '6';
  }

  else if(tm1 == 7)
  {
   cupteams[ttt] = '7';
  }
  else
  {

  }

}

void cup::resetcup()
{
    strcpy(cupteams,"3333333311111111111111111111111111111111");
}

int cup::showgamenumber()
{
    return gamenumber;
}

void cup::gamenumberplusone()
{
    gamenumber = gamenumber + 1;
}

void cup::resetgamenumber()
{
    gamenumber = 1;
}



void cup::save(fstream& op)
{

  op.write((char *)&cupteams, sizeof(cupteams));
  op.write((char *)&gamenumber, sizeof(gamenumber));
}

int cup::load(fstream& ip)
{
  if(ip.eof())
  return 0;


  ip.read((char *)&cupteams, sizeof(cupteams));
  ip.read((char *)&gamenumber, sizeof(gamenumber));

  return 1;
}
