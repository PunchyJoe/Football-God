#include "footballgod.h"



void promrelaga(void)
{
        fstream gm;
        fstream recm;
        fstream fx;
        fstream yn;
        fstream wecm;
        fstream finan;
        int tp1, ok1, at1, at2, df1, df2;
        int cs1, cs2, tp2, ok2, ps1, ps2;
        int at0, df0, ps0, at4, df4, ps4;
        int ht1 = 0;
        int ht2 = 0;
        int ft1 = 0;
        int ft2 = 0;
        int ook2 = 0;
        int ttp2 = 0;
        int fuckingpens = 0;
        int pennum = 0;
        int shotsongoal1, shotsongoal2, shotsongoal1et, shotsongoal2et;
        int posesion1, posesion2, posesion1et, posesion2et, defoff;
        int bigadvantage, totalattack1, totalattack2;
        int totaldefence1, totaldefence2, totalpassing1, totalpassing2;
        int shoot1, shoot2, ver, bub;
        int mins = 90;
        int tpoints1, tpoints2, goaldiff1, goaldiff2, p, j, u, e;
        int pl1, pl2, wins1, wins2, draws1, draws2, loses1, loses2;
        int gf1, gf2, ga1, ga2;
        int orig1, orig2;
        int att1, att2, def1, def2, pass1, pass2;
        int tcap1, tcap2, tbal1, tbal2;
        int round, year;
        char mst1[80];
        char mst2[80];
        char sst1[80];
        char sst2[80];
        char rst1[10];
        char rst2[10];
        char team1[80];
        char team2[80];

        fixtureselite fixes;
        fixturesconone fixes2;
        fixturescontwo fixes3;

        cup pups;

        srand ( (unsigned int)time(NULL) );

       team* igm = new team[NUM_OF_TEAMS_TOTAL];

       //vector<team> igm (NUM_OF_TEAMS_TOTAL);

       gm.open("TEAMS.BIN",ios_base::binary|ios_base::in);
        if(gm.fail())
        {
          cout << "Could not open teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }


  for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
  {
      igm[p].load(gm);
  }

    gm.close();

    gm.open("TEAMSBACKUP.BIN",ios_base::binary|ios_base::out);
        if(gm.fail())
        {
          cout << "Could not open teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }
   for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
   {
      igm[p].save(gm);
   }

    gm.close();

      fx.open("ELITEFIXTURES.BIN",ios_base::binary|ios_base::in);
        if(fx.fail())
        {
          cout << "Could not open teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

     fixes.load(fx);


     fx.close();


    fixes.plusonegamenumber();

    bub = fixes.checkgamenumber();


   if(bub < 113)
      {
        cout << "Union Elite season not over - Not all matches played" << endl;
        delete [] igm;
//        igm = nullptr;
        (void)_getch();
        return;
      }





        fx.open("ONECONFIXTURES.BIN",ios::binary|ios::in);
        if(fx.fail())
        {
          cout << "Could not open fictures2 file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        fixes2.load(fx);

        fx.close();

        tp1 = fixes2.checkturn();

        ok1 = fixes2.teamchecker(tp1);

        fixes2.turnplus();

     if(ok1 < 24)
      {
       cout << "Confederacy 1 Not Over" << endl;
       (void)_getch();
       return;
      }



      fx.open("TWOCONFIXTURES.BIN",ios_base::binary|ios_base::in);
        if(fx.fail())
        {
          cout << "Could not open fixtures file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        fixes3.load(fx);

        fx.close();

        tp1 = fixes3.checkturn();

        ok1 = fixes3.teamchecker(tp1);

        fixes3.turnplus();


      if(ok1 < 40)
      {
       cout << "Confederacy 2 Not Over" << endl;
       (void)_getch();
       return;
      }


        fx.open("CUP.BIN",ios_base::binary|ios_base::in);
        if(fx.fail())
        {
          cout << "Could not open cup file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        pups.load(fx);

        fx.close();

        round = pups.roundchecker();

        if(round <= 6)
        {
           cout << "Cup Not Over" << endl;
           (void)_getch();
           return;
        }




        yn.open("YEAR.BIN",ios_base::binary|ios_base::in);
        if(yn.fail())
        {
        }

        yn.read((char *)&year, sizeof(year));

        yn.close();



        recm.open("SEASONELITE.txt",ios_base::app | ios_base::out);
        if(recm.fail())
        {
          cout << "Could not open season elite table file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }



           for (p = 0; p < 8; p++)
            {
              for (j = 0; j < 7; j++)
               {


                 igm[j].teamshow(mst1);
                 igm[j+1].teamshow(mst2);
                 igm[j].stadiumshow(sst1);
                 igm[j+1].stadiumshow(sst2);
                 igm[j].regionshow(rst1);
                 igm[j+1].regionshow(rst2);
                 pl1  = igm[j].showplayed();
                 pl2  = igm[j+1].showplayed();
                 wins1  = igm[j].showwins();
                 wins2  = igm[j+1].showwins();
                 draws1 = igm[j].showdraws();
                 draws2 = igm[j+1].showdraws();
                 loses1 = igm[j].showloses();
                 loses2 = igm[j+1].showloses();
                 gf1 = igm[j].showgoalsfor();
                 gf2 = igm[j+1].showgoalsfor();
                 ga1 = igm[j].showgoalsags();
                 ga2 = igm[j+1].showgoalsags();
                 goaldiff1  = igm[j].showgoaldiff();
                 goaldiff2  = igm[j+1].showgoaldiff();
                 tpoints1  = igm[j].showpoints();
                 tpoints2 = igm[j+1].showpoints();



                 orig1 = igm[j].ordershow();
                 orig2 = igm[j+1].ordershow();
                 att1 = igm[j].attackshow();
                 att2 = igm[j+1].attackshow();
                 def1 = igm[j].defenceshow();
                 def2 = igm[j+1].defenceshow();
                 pass1 = igm[j].passingshow();
                 pass2 = igm[j+1].passingshow();
                 shoot1 = igm[j].shootingshow();
                 shoot2 = igm[j+1].shootingshow();
                 tcap1 = igm[j].capacityshow();
                 tcap2 = igm[j+1].capacityshow();
                 tbal1 = igm[j].balanceshow();
                 tbal2 = igm[j+1].balanceshow();



                 if (tpoints1 < tpoints2)
                  {
                    igm[j].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                    igm[j+1].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);
                  }

                  if (tpoints1 == tpoints2)
                   {
                        if (goaldiff1 < goaldiff2)
                        {
                           igm[j].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                           igm[j+1].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);
                        }

                        if (goaldiff1 == goaldiff2)
                       {
                          if (gf1 < gf2)
                           {
                              igm[j].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                              igm[j+1].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);
                           }

                          if (gf1 == gf2)
                          {
                               if (ga1 > ga2)
                                {
                                igm[j].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                                igm[j+1].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);
                                }
                          }
                      }
                 }
              }
            }



         u = 1;


         recm << "                        " << year << endl;
         recm << "                        ATLANTIS UNION ELITE                       " << endl;
         recm << "-------------------------------------------------------------------" << endl;
         recm << "                            PL   W   D   L    GF    GA    GD    PTS" << endl << endl;
         recm << "___________________________________________________________________" << endl;

         for (e = 0; e < 8; e++)
         {

           recm << "# " << setw(2) << u << "  ";
           igm[e].showendteams(recm);
           if(u == 1 || u == 7)
              recm <<"____________________________________________________________________" << endl;
           u++;
        }


      recm <<"____________________________________________________________________" << endl << endl;



       recm << endl;

       recm.close();




       recm.open("SEASONCONONE.txt",ios_base::app | ios_base::out);
        if(recm.fail())
        {
          cout << "Could not open confederate 1 table file file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }



            for (p = 8; p < 24; p++)
            {
              for (j = 8; j < 23; j++)
               {


                 igm[j].teamshow(mst1);
                 igm[j+1].teamshow(mst2);
                 igm[j].stadiumshow(sst1);
                 igm[j+1].stadiumshow(sst2);
                 igm[j].regionshow(rst1);
                 igm[j+1].regionshow(rst2);
                 pl1  = igm[j].showplayed();
                 pl2  = igm[j+1].showplayed();
                 wins1  = igm[j].showwins();
                 wins2  = igm[j+1].showwins();
                 draws1 = igm[j].showdraws();
                 draws2 = igm[j+1].showdraws();
                 loses1 = igm[j].showloses();
                 loses2 = igm[j+1].showloses();
                 gf1 = igm[j].showgoalsfor();
                 gf2 = igm[j+1].showgoalsfor();
                 ga1 = igm[j].showgoalsags();
                 ga2 = igm[j+1].showgoalsags();
                 goaldiff1  = igm[j].showgoaldiff();
                 goaldiff2  = igm[j+1].showgoaldiff();
                 tpoints1  = igm[j].showpoints();
                 tpoints2 = igm[j+1].showpoints();


                 orig1 = igm[j].ordershow();
                 orig2 = igm[j+1].ordershow();
                 att1 = igm[j].attackshow();
                 att2 = igm[j+1].attackshow();
                 def1 = igm[j].defenceshow();
                 def2 = igm[j+1].defenceshow();
                 pass1 = igm[j].passingshow();
                 pass2 = igm[j+1].passingshow();
                 shoot1 = igm[j].shootingshow();
                 shoot2 = igm[j+1].shootingshow();
                 tcap1 = igm[j].capacityshow();
                 tcap2 = igm[j+1].capacityshow();
                 tbal1 = igm[j].balanceshow();
                 tbal2 = igm[j+1].balanceshow();



                   if (tpoints1 < tpoints2)
                  {
                    igm[j].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                    igm[j+1].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);
                  }

                  if (tpoints1 == tpoints2)
                   {
                        if (goaldiff1 < goaldiff2)
                        {
                           igm[j].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                           igm[j+1].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);
                        }

                        if (goaldiff1 == goaldiff2)
                       {
                          if (gf1 < gf2)
                           {
                              igm[j].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                              igm[j+1].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);
                           }

                          if (gf1 == gf2)
                          {
                               if (ga1 > ga2)
                                {
                                igm[j].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                                igm[j+1].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);
                                }
                          }
                      }
                 }
              }
            }

         u = 1;


         recm << "                        " << year << endl;
         recm << "                        ATLANTIS CONFEDERACY 1                     " << endl;
         recm << "-------------------------------------------------------------------" << endl;
         recm << "                            PL   W   D   L    GF    GA    GD    PTS" << endl << endl;
         recm << "___________________________________________________________________" << endl;

         for (e = 8; e < 24; e++)
         {

           recm << "# " << setw(2) << u << "  ";
           igm[e].showendteams(recm);
           if(u == 1 || u == 14)
              recm <<"____________________________________________________________________" << endl;
           u++;
        }


      recm <<"____________________________________________________________________" << endl;





     recm << endl;


     recm.close();



        recm.open("SEASONCONTWO.txt",ios_base::app | ios_base::out);
        if(recm.fail())
        {
          cout << "Could not open confederate 2 table file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }




            for (p = 24; p < 40; p++)
            {
              for (j = 24; j < 39; j++)
               {


                 igm[j].teamshow(mst1);
                 igm[j+1].teamshow(mst2);
                 igm[j].stadiumshow(sst1);
                 igm[j+1].stadiumshow(sst2);
                 igm[j].regionshow(rst1);
                 igm[j+1].regionshow(rst2);
                 pl1  = igm[j].showplayed();
                 pl2  = igm[j+1].showplayed();
                 wins1  = igm[j].showwins();
                 wins2  = igm[j+1].showwins();
                 draws1 = igm[j].showdraws();
                 draws2 = igm[j+1].showdraws();
                 loses1 = igm[j].showloses();
                 loses2 = igm[j+1].showloses();
                 gf1 = igm[j].showgoalsfor();
                 gf2 = igm[j+1].showgoalsfor();
                 ga1 = igm[j].showgoalsags();
                 ga2 = igm[j+1].showgoalsags();
                 goaldiff1  = igm[j].showgoaldiff();
                 goaldiff2  = igm[j+1].showgoaldiff();
                 tpoints1  = igm[j].showpoints();
                 tpoints2 = igm[j+1].showpoints();


                 orig1 = igm[j].ordershow();
                 orig2 = igm[j+1].ordershow();
                 att1 = igm[j].attackshow();
                 att2 = igm[j+1].attackshow();
                 def1 = igm[j].defenceshow();
                 def2 = igm[j+1].defenceshow();
                 pass1 = igm[j].passingshow();
                 pass2 = igm[j+1].passingshow();
                 shoot1 = igm[j].shootingshow();
                 shoot2 = igm[j+1].shootingshow();
                 tcap1 = igm[j].capacityshow();
                 tcap2 = igm[j+1].capacityshow();
                 tbal1 = igm[j].balanceshow();
                 tbal2 = igm[j+1].balanceshow();



                 if (tpoints1 < tpoints2)
                  {
                    igm[j].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                    igm[j+1].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);
                  }

                  if (tpoints1 == tpoints2)
                   {
                        if (goaldiff1 < goaldiff2)
                        {
                           igm[j].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                           igm[j+1].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);
                        }

                        if (goaldiff1 == goaldiff2)
                       {
                          if (gf1 < gf2)
                           {
                              igm[j].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                              igm[j+1].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);
                           }

                          if (gf1 == gf2)
                          {
                               if (ga1 > ga2)
                                {
                                igm[j].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                                igm[j+1].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);
                                }
                          }
                      }
                 }
              }
            }

         u = 1;


         recm << "                        " << year << endl;
         recm << "                        ATLANTIS CONFEDERACY 2                    " << endl;
         recm << "-------------------------------------------------------------------" << endl;
         recm << "                            PL   W   D   L    GF    GA    GD    PTS" << endl << endl;
         recm << "___________________________________________________________________" << endl;

         for (e = 24; e < 40; e++)
         {

           recm << "# " << setw(2) << u << "  ";
           igm[e].showendteams(recm);
           if(u == 2 || u == 15)
              recm <<"____________________________________________________________________" << endl;
           u++;
        }


         recm <<"____________________________________________________________________" << endl;



         recm << endl;


        recm.close();

        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
         {
           igm[p].changenumber(p);
         }

        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
         {
           igm[p].sortmoney(year);
         }

       wecm.open("ELITERESULTS.txt",ios_base::app | ios_base::out);
        if(wecm.fail())
        {
          cout << "Could not open Records file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }


         tp1 = 7;
         ok1 = 8;



         igm[tp1].teamshow(team1);
         igm[ok1].teamshow(team2);
         at1 = igm[tp1].attackshow();
         at2 = igm[ok1].attackshow();
         df1 = igm[tp1].defenceshow();
         df2 = igm[ok1].defenceshow();
         ps1 = igm[tp1].passingshow();
         ps2 = igm[ok1].passingshow();
         shoot1 = igm[tp1].shootingshow();
         shoot2 = igm[ok1].shootingshow();
         cs1 = igm[tp1].capacityshow();
         cs2 = igm[ok1].capacityshow();


       cout << endl << endl << " ELITE PLAYOFF:   " << team1 << "  VS  " << team2 << " - Capitalis Stadium" << "  cap:100000" << endl;
       cout << "  KICK OFF - Press a key" << endl;
       (void)_getch();

       tp2 = 0;
       ok2 = 0;
       shotsongoal1 = 0;
       shotsongoal2 = 0;
       posesion1 = 0;
       posesion2 = 0;


      if (cs1 > cs2)
       {
          bigadvantage = (cs1 - cs2) / SUPERIORITY;
          ps1 = ps1 + bigadvantage;
       }

       if (cs2 > cs1)
       {
          bigadvantage = (cs2 - cs1) / SUPERIORITY;
          ps2 = ps2 + bigadvantage;
       }



      for(p = 0; p < 90; p++)
        {

      at0 = rand() % 151;
      df0 = rand() % 101 + 100;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + 100;
      ps4 = rand() % 151;



      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;

      ver = rand() % 101;

      if(p == 45)
      {
        cout << "  HALF TIME - Press a key" << endl;
        (void)_getch();
        ht1 = tp2;
        ht2 = ok2;
      }






      if(totalpassing1 >= totalpassing2)
      {
          posesion1 = posesion1 + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1 = shotsongoal1 + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             cout << "  GOAL!! Press a key" << endl;
             (void)_getch();
             }
          }
        }
      }


      if(totalpassing2 > totalpassing1)
      {
          posesion2 = posesion2 + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2 = shotsongoal2 + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             cout << "  GOAL!! Press a key" << endl;
             (void)_getch();
             }
          }
        }
      }


       cout << "minute " << p+1 << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
       chrono::seconds dura(1);
       this_thread::sleep_for(dura);

        }

     if(tp2 == ok2)
       {
      cout << "Extra Time " << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
      cout << "Press a key" << endl;
      (void)_getch();
      p = 90;
      defoff = 100;
      shotsongoal1et = 0;
      shotsongoal2et = 0;
      posesion1et = 0;
      posesion2et = 0;
      ft1 = tp2;
      ft2 = ok2;

      do{

      at0 = rand() % 151;
      df0 = rand() % 101 + defoff;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + defoff;
      ps4 = rand() % 151;



      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;

      ver = rand() % 101;


      if(totalpassing1 >= totalpassing2)
      {
          posesion1et = posesion1et + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1et = shotsongoal1et + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             cout << "  GOAL!! Press a key" << endl;
             (void)_getch();
             }
          }
        }
      }


      if(totalpassing2 > totalpassing1)
      {
          posesion2et = posesion2et + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2et = shotsongoal2et + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             cout << "  GOAL!! Press a key" << endl;
             (void)_getch();
             }
          }
        }
      }

       cout << "extra time minute " << p+1 << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
       chrono::seconds dura(1);
       this_thread::sleep_for(dura);
       p++;
       mins++;
       if(defoff > 0)
         {
            --defoff;
         }
         }while(p <= 119);

        if(tp2 == ok2 && p > 119)
        {
            cout << "PENALTIES...." << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl << endl;
            fuckingpens = 1;
            while(ttp2 == ook2)
            {
                pennum++;
                cout << "Penalty number:  " << pennum << "   " << team1 << " " << ttp2 << "   " << team2 << " " << ook2 << endl << endl;
                ver = rand() % 201;
                cout << team1 << "  STEPS UP......" << endl << endl;
                (void)_getch();
                if(shoot1 < ver)
                {
                  ttp2 = ttp2 + 1;
                  cout << "  GOAL!! Press a key" << endl << endl;
                  (void)_getch();
                }
                else
                {
                  cout << "  MISSED!! Press a key" << endl << endl;
                  (void)_getch();
                }

                ver = rand() % 201;
                cout << team2 << "  STEPS UP......" << endl << endl;
                (void)_getch();
                if(shoot2 < ver)
                {
                  ook2 = ook2 + 1;
                  cout << "  GOAL!! Press a key" << endl << endl;
                  (void)_getch();
                }
                else
                {
                  cout << "  MISSED!! Press a key" << endl << endl;
                  (void)_getch();
                }
            }
        }
    }

        cout << "  FULL TIME - Press a key" << endl;
        (void)_getch();

         cout << endl << endl << "             FINAL RESULT" << endl;
         cout << endl << endl << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
         cout << "  HT:" << ht1 << "-" << ht2 << "  SHOTS ON GOAL: " << shotsongoal1 << "-" << shotsongoal2 << right
         << "  POSSESION: " << posesion1 << "-" << posesion2 << endl;

         wecm << year << " " << right << setw(2) << "PLAYOFF ELITE FINAL: " << right << setw(20) << team1 << " " << tp2 << right << setw(20) << team2 << " " << ok2 << "  HT:" << ht1 << "-" << ht2 << right << setw(20) << "SHOTS ON GOAL: "
         << right << setw(4) << shotsongoal1 << "   - " << right << setw(4) << shotsongoal2 << right << setw(20) << "POSSESION: "
         << right << setw(4) << posesion1 << "   - " << right << setw(4) << posesion2;

        if(mins > 90)
         {
            wecm << "  A.E.T ";
            cout << "  A.E.T ";
            if(fuckingpens == 1)
            {
            wecm << right << setw(10)<< "PENS: " << ttp2 << "-" << ook2 << "  FT:" << ft1 << "-" << ft2 << setw(20) << "ETSHOTS: "
             << right << setw(4) << shotsongoal1et << "   - " << right << setw(4) << shotsongoal2et << right << setw(10) << "ETPOS: "
             << right << setw(4) << posesion1et << "   - " << right << setw(4) << posesion2et;
            cout << "  PENS: " << ttp2 << "-" << ook2 << "  FT:" << ft1 << "-" << ft2 << "  ETSHOTS: "
             << shotsongoal1et << " - " << shotsongoal2et << "  ETPOS: " << posesion1et << " - " << posesion2et;
            }
            else
            {
            wecm << right << setw(18)<< "FT:" << ft1 << "-" << ft2 << setw(20) << "ETSHOTS: "
            << right << setw(4) << shotsongoal1et << "   - " << right << setw(4) << shotsongoal2et << right << setw(10) << "ETPOS: "
            << right << setw(4) << posesion1et << "   - " << right << setw(4) << posesion2et;
            cout << "  FT:" << ft1 << "-" << ft2 << "  ETSHOTS: " << shotsongoal1et << " - " << shotsongoal2et << "  ETPOS: "
            << posesion1et << " - " << posesion2et;
            }

            wecm << endl;
            cout << endl;
         }
        else
         {
            wecm << endl;
            cout << endl;
         }

        tp2 = tp2 + ttp2;
        ok2 = ok2 + ook2;
        ttp2 = 0;
        ook2 = 0;
        fuckingpens = 0;
        pennum = 0;

        if(tp2 < ok2)
        {

                 igm[7].teamshow(mst1);
                 igm[8].teamshow(mst2);
                 igm[7].stadiumshow(sst1);
                 igm[8].stadiumshow(sst2);
                 igm[7].regionshow(rst1);
                 igm[8].regionshow(rst2);
                 pl1  = igm[7].showplayed();
                 pl2  = igm[8].showplayed();
                 wins1  = igm[7].showwins();
                 wins2  = igm[8].showwins();
                 draws1 = igm[7].showdraws();
                 draws2 = igm[8].showdraws();
                 loses1 = igm[7].showloses();
                 loses2 = igm[8].showloses();
                 gf1 = igm[7].showgoalsfor();
                 gf2 = igm[8].showgoalsfor();
                 ga1 = igm[7].showgoalsags();
                 ga2 = igm[8].showgoalsags();
                 goaldiff1  = igm[7].showgoaldiff();
                 goaldiff2  = igm[8].showgoaldiff();
                 tpoints1  = igm[7].showpoints();
                 tpoints2 = igm[8].showpoints();


                 orig1 = igm[7].ordershow();
                 orig2 = igm[8].ordershow();
                 att1 = igm[7].attackshow();
                 att2 = igm[8].attackshow();
                 def1 = igm[7].defenceshow();
                 def2 = igm[8].defenceshow();
                 pass1 = igm[7].passingshow();
                 pass2 = igm[8].passingshow();
                 shoot1 = igm[7].shootingshow();
                 shoot2 = igm[8].shootingshow();
                 tcap1 = igm[7].capacityshow();
                 tcap2 = igm[8].capacityshow();
                 tbal1 = igm[7].balanceshow();
                 tbal2 = igm[8].balanceshow();

                 igm[7].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                 igm[8].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);

                 igm[7].promo(1);
                 igm[8].promo(2);

                 igm[7].intocredit(year);
                 igm[8].intodebit(year);


             }





                 igm[22].teamshow(mst1);
                 igm[24].teamshow(mst2);
                 igm[22].stadiumshow(sst1);
                 igm[24].stadiumshow(sst2);
                 igm[22].regionshow(rst1);
                 igm[24].regionshow(rst2);
                 pl1  = igm[22].showplayed();
                 pl2  = igm[24].showplayed();
                 wins1  = igm[22].showwins();
                 wins2  = igm[24].showwins();
                 draws1 = igm[22].showdraws();
                 draws2 = igm[24].showdraws();
                 loses1 = igm[22].showloses();
                 loses2 = igm[24].showloses();
                 gf1 = igm[22].showgoalsfor();
                 gf2 = igm[24].showgoalsfor();
                 ga1 = igm[22].showgoalsags();
                 ga2 = igm[24].showgoalsags();
                 goaldiff1  = igm[22].showgoaldiff();
                 goaldiff2  = igm[24].showgoaldiff();
                 tpoints1  = igm[22].showpoints();
                 tpoints2 = igm[24].showpoints();


                 orig1 = igm[22].ordershow();
                 orig2 = igm[24].ordershow();
                 att1 = igm[22].attackshow();
                 att2 = igm[24].attackshow();
                 def1 = igm[22].defenceshow();
                 def2 = igm[24].defenceshow();
                 pass1 = igm[22].passingshow();
                 pass2 = igm[24].passingshow();
                 shoot1 = igm[22].shootingshow();
                 shoot2 = igm[24].shootingshow();
                 tcap1 = igm[22].capacityshow();
                 tcap2 = igm[24].capacityshow();
                 tbal1 = igm[22].balanceshow();
                 tbal2 = igm[24].balanceshow();

                 igm[22].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                 igm[24].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);

                 igm[22].promo(3);
                 igm[24].promo(4);


                 igm[23].teamshow(mst1);
                 igm[25].teamshow(mst2);
                 igm[23].stadiumshow(sst1);
                 igm[25].stadiumshow(sst2);
                 igm[23].regionshow(rst1);
                 igm[25].regionshow(rst2);
                 pl1  = igm[23].showplayed();
                 pl2  = igm[25].showplayed();
                 wins1  = igm[23].showwins();
                 wins2  = igm[25].showwins();
                 draws1 = igm[23].showdraws();
                 draws2 = igm[25].showdraws();
                 loses1 = igm[23].showloses();
                 loses2 = igm[25].showloses();
                 gf1 = igm[23].showgoalsfor();
                 gf2 = igm[25].showgoalsfor();
                 ga1 = igm[23].showgoalsags();
                 ga2 = igm[25].showgoalsags();
                 goaldiff1  = igm[23].showgoaldiff();
                 goaldiff2  = igm[25].showgoaldiff();
                 tpoints1  = igm[23].showpoints();
                 tpoints2 = igm[25].showpoints();

                 orig1 = igm[23].ordershow();
                 orig2 = igm[25].ordershow();
                 att1 = igm[23].attackshow();
                 att2 = igm[25].attackshow();
                 def1 = igm[23].defenceshow();
                 def2 = igm[25].defenceshow();
                 pass1 = igm[23].passingshow();
                 pass2 = igm[25].passingshow();
                 shoot1 = igm[23].shootingshow();
                 shoot2 = igm[25].shootingshow();
                 tcap1 = igm[23].capacityshow();
                 tcap2 = igm[25].capacityshow();
                 tbal1 = igm[23].balanceshow();
                 tbal2 = igm[25].balanceshow();

                 igm[23].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                 igm[25].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);

                 igm[23].promo(3);
                 igm[25].promo(4);

         wecm.close();




        wecm.open("TWOCONRESULTS.txt",ios_base::app | ios_base::out);
        if(wecm.fail())
        {
          cout << "Could not open Records file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }




         tp1 = 39;

         igm[39].regionshow(rst1);
         igm[40].regionshow(rst2);

         if(rst1[0] == rst2[0])
         {
           ok1 = 40;
         }
         else
         {
           ok1 = 41;
         }



         igm[tp1].teamshow(team1);
         igm[ok1].teamshow(team2);
         at1 = igm[tp1].attackshow();
         at2 = igm[ok1].attackshow();
         df1 = igm[tp1].defenceshow();
         df2 = igm[ok1].defenceshow();
         ps1 = igm[tp1].passingshow();
         ps2 = igm[ok1].passingshow();
         shoot1 = igm[tp1].shootingshow();
         shoot2 = igm[ok1].shootingshow();
         cs1 = igm[tp1].capacityshow();
         cs2 = igm[ok1].capacityshow();



       cout << endl << endl << " CONFEDERACY PLAYOFF:   " << team1 << "  VS  " << team2 << " - White City Stadium" << "  cap:50000" << endl;
       cout << "  KICK OFF - Press a key" << endl;
       (void)_getch();

       tp2 = 0;
       ok2 = 0;
       shotsongoal1 = 0;
       shotsongoal2 = 0;
       posesion1 = 0;
       posesion2 = 0;


      if (cs1 > cs2)
       {
          bigadvantage = (cs1 - cs2) / SUPERIORITY;
          ps1 = ps1 + bigadvantage;
       }

       if (cs2 > cs1)
       {
          bigadvantage = (cs2 - cs1) / SUPERIORITY;
          ps2 = ps2 + bigadvantage;
       }



      for(p = 0; p < 90; p++)
        {

      at0 = rand() % 151;
      df0 = rand() % 101 + 100;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + 100;
      ps4 = rand() % 151;



      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;

      ver = rand() % 101;

      if(p == 45)
      {
        cout << "  HALF TIME - Press a key" << endl;
        (void)_getch();
         ht1 = tp2;
         ht2 = ok2;
      }






      if(totalpassing1 >= totalpassing2)
      {
          posesion1 = posesion1 + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1 = shotsongoal1 + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             cout << "  GOAL!! Press a key" << endl;
             (void)_getch();
             }
          }
        }
      }


      if(totalpassing2 > totalpassing1)
      {
          posesion2 = posesion2 + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2 = shotsongoal2 + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             cout << "  GOAL!! Press a key" << endl;
             (void)_getch();
             }
          }
        }
      }


       cout << "minute " << p+1 << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
       chrono::seconds dura(1);
       this_thread::sleep_for(dura);

        }

     if(tp2 == ok2)
       {
      cout << "Extra Time " << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
      cout << "Press a key" << endl;
      (void)_getch();
      p = 90;
      defoff = 100;
      shotsongoal1et = 0;
      shotsongoal2et = 0;
      posesion1et = 0;
      posesion2et = 0;
      ft1 = tp2;
      ft2 = ok2;

      do{

      at0 = rand() % 151;
      df0 = rand() % 101 + defoff;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + defoff;
      ps4 = rand() % 151;



      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;

      ver = rand() % 101;


      if(totalpassing1 >= totalpassing2)
      {
          posesion1et = posesion1et + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1et = shotsongoal1et + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             cout << "  GOAL!! Press a key" << endl;
             (void)_getch();
             }
          }
        }
      }


      if(totalpassing2 > totalpassing1)
      {
          posesion2et = posesion2et + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2et = shotsongoal2et + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             cout << "  GOAL!! Press a key" << endl;
             (void)_getch();
             }
          }
        }
      }

       cout << "extra time minute " << p+1 << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
       chrono::seconds dura(1);
       this_thread::sleep_for(dura);
       p++;
       mins++;
       if(defoff > 0)
         {
            --defoff;
         }
          }while(p <=119);

        if(tp2 == ok2 && p > 119)
        {
            cout << "PENALTIES...." << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl << endl;
            fuckingpens = 1;
            while(ttp2 == ook2)
            {
                pennum++;
                cout << "Penalty number:  " << pennum << "   " << team1 << " " << ttp2 << "   " << team2 << " " << ook2 << endl << endl;
                ver = rand() % 201;
                cout << team1 << "  STEPS UP......" << endl << endl;
                (void)_getch();
                if(shoot1 < ver)
                {
                  ttp2 = ttp2 + 1;
                  cout << "  GOAL!! Press a key" << endl << endl;
                  (void)_getch();
                }
                else
                {
                  cout << "  MISSED!! Press a key" << endl << endl;
                  (void)_getch();
                }

                ver = rand() % 201;
                cout << team2 << "  STEPS UP......" << endl << endl;
                (void)_getch();
                if(shoot2 < ver)
                {
                  ook2 = ook2 + 1;
                  cout << "  GOAL!! Press a key" << endl << endl;
                  (void)_getch();
                }
                else
                {
                  cout << "  MISSED!! Press a key" << endl << endl;
                  (void)_getch();
                }
            }
        }
    }

        cout << "  FULL TIME - Press a key" << endl;
        (void)_getch();

         cout << endl << endl << "             FINAL RESULT" << endl;
         cout << endl << endl << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
         cout << "  HT:" << ht1 << "-" << ht2 << "  SHOTS ON GOAL: " << shotsongoal1 << "-" << shotsongoal2 << right
         << "  POSSESION: " << posesion1 << "-" << posesion2 << endl;

         wecm << year << " " << right << setw(2) << "PLAYOFF CONFEDERACY FINAL: " << right << setw(20) << team1 << " " << tp2 << right << setw(20) << team2 << " " << ok2 << "  HT:" << ht1 << "-" << ht2 << right << setw(20) << "SHOTS ON GOAL: "
         << right << setw(4) << shotsongoal1 << "   - " << right << setw(4) << shotsongoal2 << right << setw(20) << "POSSESION: "
         << right << setw(4) << posesion1 << "   - " << right << setw(4) << posesion2;

         if(mins > 90)
         {
            wecm << "  A.E.T ";
            cout << "  A.E.T ";
            if(fuckingpens == 1)
            {
            wecm << right << setw(10)<< "PENS: " << ttp2 << "-" << ook2 << "  FT:" << ft1 << "-" << ft2 << setw(20) << "ETSHOTS: "
             << right << setw(4) << shotsongoal1et << "   - " << right << setw(4) << shotsongoal2et << right << setw(10) << "ETPOS: "
             << right << setw(4) << posesion1et << "   - " << right << setw(4) << posesion2et;
            cout << "  PENS: " << ttp2 << "-" << ook2 << "  FT:" << ft1 << "-" << ft2 << "  ETSHOTS: "
             << shotsongoal1et << " - " << shotsongoal2et << "  ETPOS: " << posesion1et << " - " << posesion2et;
            }
            else
            {
            wecm << right << setw(18)<< "FT:" << ft1 << "-" << ft2 << setw(20) << "ETSHOTS: "
            << right << setw(4) << shotsongoal1et << "   - " << right << setw(4) << shotsongoal2et << right << setw(10) << "ETPOS: "
            << right << setw(4) << posesion1et << "   - " << right << setw(4) << posesion2et;
            cout << "  FT:" << ft1 << "-" << ft2 << "  ETSHOTS: " << shotsongoal1et << " - " << shotsongoal2et << "  ETPOS: "
            << posesion1et << " - " << posesion2et;
            }

            wecm << endl;
            cout << endl;
         }
        else
         {
            wecm << endl;
            cout << endl;
         }


        tp2 = tp2 + ttp2;
        ok2 = ok2 + ook2;


        if(tp2 < ok2)
        {
               if(ok1 == 40)
                 {
                 igm[39].teamshow(mst1);
                 igm[40].teamshow(mst2);
                 igm[39].stadiumshow(sst1);
                 igm[40].stadiumshow(sst2);
                 pl1  = igm[39].showplayed();
                 pl2  = igm[40].showplayed();
                 wins1  = igm[39].showwins();
                 wins2  = igm[40].showwins();
                 draws1 = igm[39].showdraws();
                 draws2 = igm[40].showdraws();
                 loses1 = igm[39].showloses();
                 loses2 = igm[40].showloses();
                 gf1 = igm[39].showgoalsfor();
                 gf2 = igm[40].showgoalsfor();
                 ga1 = igm[39].showgoalsags();
                 ga2 = igm[40].showgoalsags();
                 goaldiff1  = igm[39].showgoaldiff();
                 goaldiff2  = igm[40].showgoaldiff();
                 tpoints1  = igm[39].showpoints();
                 tpoints2 = igm[40].showpoints();


                 orig1 = igm[39].ordershow();
                 orig2 = igm[40].ordershow();
                 att1 = igm[39].attackshow();
                 att2 = igm[40].attackshow();
                 def1 = igm[39].defenceshow();
                 def2 = igm[40].defenceshow();
                 pass1 = igm[39].passingshow();
                 pass2 = igm[40].passingshow();
                 shoot1 = igm[39].shootingshow();
                 shoot2 = igm[40].shootingshow();
                 tcap1 = igm[39].capacityshow();
                 tcap2 = igm[40].capacityshow();
                 tbal1 = igm[39].balanceshow();
                 tbal2 = igm[40].balanceshow();

                 igm[39].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                 igm[40].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);

                 }

                 else
                 {
                 igm[39].teamshow(mst1);
                 igm[41].teamshow(mst2);
                 igm[39].stadiumshow(sst1);
                 igm[41].stadiumshow(sst2);
                 igm[39].regionshow(rst1);
                 igm[41].regionshow(rst2);
                 pl1  = igm[39].showplayed();
                 pl2  = igm[41].showplayed();
                 wins1  = igm[39].showwins();
                 wins2  = igm[41].showwins();
                 draws1 = igm[39].showdraws();
                 draws2 = igm[41].showdraws();
                 loses1 = igm[39].showloses();
                 loses2 = igm[41].showloses();
                 gf1 = igm[39].showgoalsfor();
                 gf2 = igm[41].showgoalsfor();
                 ga1 = igm[39].showgoalsags();
                 ga2 = igm[41].showgoalsags();
                 goaldiff1  = igm[39].showgoaldiff();
                 goaldiff2  = igm[41].showgoaldiff();
                 tpoints1  = igm[39].showpoints();
                 tpoints2 = igm[41].showpoints();


                 orig1 = igm[39].ordershow();
                 orig2 = igm[41].ordershow();
                 att1 = igm[39].attackshow();
                 att2 = igm[41].attackshow();
                 def1 = igm[39].defenceshow();
                 def2 = igm[41].defenceshow();
                 pass1 = igm[39].passingshow();
                 pass2 = igm[41].passingshow();
                 shoot1 = igm[39].shootingshow();
                 shoot2 = igm[41].shootingshow();
                 tcap1 = igm[39].capacityshow();
                 tcap2 = igm[41].capacityshow();
                 tbal1 = igm[39].balanceshow();
                 tbal2 = igm[41].balanceshow();

                 igm[39].swapteampromo(mst2,sst2,rst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2,orig2,att2,def2,pass2,shoot2,tcap2,tbal2);
                 igm[41].swapteampromo(mst1,sst1,rst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1,orig1,att1,def1,pass1,shoot1,tcap1,tbal1);

                 }
        }

        wecm.close();

         cout << "  END OF SEASON - Press a key" << endl;
        (void)_getch();

        finan.open("FINANCE.txt",ios_base::app | ios_base::out);
        if(finan.fail())
        {
          cout << "Could not open season elite table file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }



        gm.open("TEAMS.BIN",ios_base::binary|ios_base::out);
        if(gm.fail())
        {
          cout << "Could not open save teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
         {
           igm[p].changenumber(p);
         }

        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
         {
           igm[p].resetstats();
         }

         for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
         {
           cout << "Creating team changes for new season. team: " << p+1 << endl;
           chrono::seconds dura(5);
           this_thread::sleep_for(dura);
           igm[p].teamchanges(year);
         }

         u = 1;

         finan << "                        " << year << endl;
         finan << "                        TEAM FINANCE                               " << endl;
         finan << "-------------------------------------------------------------------" << endl;

         for (e = 0; e < 42; e++)
         {

           finan<< "# " << setw(2) << u << "  ";
           igm[e].showfinance(finan);
           u++;
        }

        finan <<"____________________________________________________________________" << endl;
        finan <<"____________________________________________________________________" << endl;
        finan <<"____________________________________________________________________" << endl << endl;


        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
         {
           igm[p].save(gm);
         }

        finan.close();
        gm.close();


        fx.open("ELITEFIXTURES.BIN",ios_base::binary|ios_base::out);
        if(fx.fail())
        {
          cout << "Could not open elite fixtures reset file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }
        fixes.startfullseasononetwo();
        fixes.save(fx);
        fx.close();

        fx.open("ONECONFIXTURES.BIN",ios_base::binary|ios_base::out);
        if(fx.fail())
        {
          cout << "Could not open confederate 1 reset file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }
        fixes2.fullseasontwo();
        fixes2.save(fx);
        fx.close();

        fx.open("TWOCONFIXTURES.BIN",ios_base::binary|ios_base::out);
        if(fx.fail())
        {
          cout << "Could not open confederate 2 reset file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }
        fixes3.fullseasonthree();
        fixes3.save(fx);
        fx.close();



        fx.open("CUP.BIN",ios_base::binary|ios_base::out);
        if(fx.fail())
        {
          cout << "Could not open cup file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        pups.resetcup();
        pups.save(fx);
        fx.close();




        wecm.open("ELITERESULTS.txt",ios_base::app | ios_base::out);
        if(wecm.fail())
        {
          cout << "Could not open Records file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        wecm << "======================================================" << endl;
        wecm << "===============END OF " << year << " SEASON <<===========" << endl;
        wecm << "======================================================" << endl;

        wecm.close();


        wecm.open("ONECONRESULTS.txt",ios_base::app | ios_base::out);
        if(wecm.fail())
        {
          cout << "Could not open Records file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        wecm << "======================================================" << endl;
        wecm << "===============END OF " << year << " SEASON <<===========" << endl;
        wecm << "======================================================" << endl;

        wecm.close();

        wecm.open("TWOCONRESULTS.txt",ios_base::app | ios_base::out);
        if(wecm.fail())
        {
          cout << "Could not open Records file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        wecm << "======================================================" << endl;
        wecm << "===============END OF " << year << " SEASON <<===========" << endl;
        wecm << "======================================================" << endl;

        wecm.close();


        year = year + 1;

        yn.open("YEAR.BIN",ios_base::binary|ios_base::out);
        if(yn.fail())
        {
          cout << "Could not open Year file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

       yn.write((char *)&year, sizeof(year));

       yn.close();




        delete [] igm;

//        igm = nullptr;


        cout << "New Season Created Successfully!!!" << endl << endl << endl;

        (void)_getch();

        exit(1);


}
