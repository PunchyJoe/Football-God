#include "footballgod.h"



void manager(void)
{

      fstream gm;
      fstream yn;

      char boot[4];
      char wantcon;

      int u = 1;
      int p, e;
      int sack;
      int year;

       srand ( (unsigned int)time(NULL) );

      yn.open("YEAR.BIN",ios_base::binary|ios_base::in);
        if(yn.fail())
        {
          cout << "Could not open Year file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        yn.read((char *)&year, sizeof(year));

        yn.close();

        if(year < 3005)
        {
          cout << "Cannot sack manager yet wait for year 3005" << endl;
          (void)_getch();
          return;
        }


       cout << "Sacking the manager and coaching staff could have a detrimental effect on any team." << endl;
       cout << "It will also cost any club a considerable amount of money." << endl;
       cout << " Do You want to continue? Y/N" << endl;
       cin  >> wantcon;

       if(wantcon != 'Y' && wantcon != 'y')
       {
         return;
       }



       team* igm = new team[NUM_OF_TEAMS_TOTAL];

       gm.open("TEAMS.BIN",ios_base::binary|ios_base::in);
        if(gm.fail())
        {
          cout << "Could not open teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }


        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
         {
            igm[p].load(gm);
         }

        gm.close();






         cout << "                        ATLANTIS ALL TEAMS                              " << endl;
         cout << "------------------------------------------------------------------------" << endl;
         cout << "                         Div  Reg        Bal                  Sta(cap)  " << endl;
         cout << "------------------------------------------------------------------------" << endl;


         for (e = 0; e < (NUM_OF_TEAMS_TOTAL - 2); e++)
         {

           cout << "# " << setw(2) << u << "  ";
           igm[e].showteamsshow();
           u++;
         }

        do
        {
        cout << endl << " Input team number to sack the manager: " << endl;
        cin >> boot;
        sack = atoi(boot);
        cout << endl;

        }while(sack <= 0 || sack > 40);

        sack = sack - 1;

        igm[sack].sackmanager(year);
        cout << "The Below team changed manager: " << endl;
        igm[sack].showteamsshow();


        gm.open("TEAMS.BIN",ios_base::binary|ios_base::out);
        if(gm.fail())
        {
          cout << "Could not open save teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
         {
            igm[p].save(gm);
         }

        gm.close();








        delete [] igm;

//        igm = nullptr;


        (void)_getch();

        return;


}
