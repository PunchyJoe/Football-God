#include "footballgod.h"

int leagueposition(int ddd,int ttt);

void bcongametwo(void)
{


  fstream gm;
  fstream fx;
  fstream recm;

  int shoot1, shoot2, ver, p;
  int ok1, tp1, at1, df1, ps1;
  int ok2, tp2, at2, df2, ps2;
  int pl1,pl2, lg1, lg2;
  int bub, bigadvantage, cs1, cs2;
  int at0, df0, ps0;
  int at4, df4, ps4;
  int ht1 = 0;
  int ht2 = 0;
  int totalattack1, totaldefence1, totalpassing1;
  int totalattack2, totaldefence2, totalpassing2;
  int shotsongoal1, shotsongoal2;
  int posesion1, posesion2, homeadvantage;
  char team1[80];
  char team2[80];
  char stadium[80];

  fixturescontwo fixes;

  srand ( (unsigned int)time(NULL) );





      fx.open("TWOCONFIXTURES.BIN",ios_base::binary|ios_base::in);
        if(fx.fail())
        {
          cout << "Could not open Fixtures3 file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

     fixes.load(fx);


     fx.close();




      bub = fixes.checkgamenumber();



      if(bub >= 241)
      {

          return;
      }

      if ((bub >= 1 && bub <= 8) || (bub >= 17 && bub <= 24) || (bub >= 33 && bub <= 40) || (bub >= 49 && bub <= 56)
          || (bub >= 65 && bub <= 72) || (bub >= 81 && bub <= 88) || (bub >= 97 && bub <= 104)
          || (bub >= 113 && bub <= 120) || (bub >= 129 && bub <= 136) || (bub >= 145 && bub <= 152)
          || (bub >= 161 && bub <= 168) || (bub >= 177 && bub <= 184) || (bub >= 193 && bub <= 200)
          || (bub >= 209 && bub <= 216) || (bub >= 225 && bub <= 232))
      {
          tp1 = fixes.checkturn();
          ok1 = fixes.teamchecker(tp1);
      }

      else
      {
          tp1 = fixes.checkturntwo();
          ok1 = fixes.teamchecker(tp1);

      }



      if(ok1 >= 40)
      {
       cout << "Confederacy 2 season over - All matches played id:40" << endl;
       chrono::seconds dura(1);
       this_thread::sleep_for(dura);
       return;
      }


    recm.open("TWOCONRESULTS.txt",ios_base::app | ios_base::out);
        if(recm.fail())
        {
          cout << "Could not open Results3 file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

     gm.open("TEAMS.BIN",ios_base::binary|ios_base::in);
        if(gm.fail())
        {
          cout << "Could not open teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }


     team* m = new team[NUM_OF_TEAMS_TOTAL];

//  vector<team> m (NUM_OF_TEAMS_TOTAL);

  for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
  {
      m[p].load(gm);
  }

    gm.close();




         m[tp1].teamshow(team1);
         m[ok1].teamshow(team2);
         m[tp1].stadiumshow(stadium);
         pl1 = m[tp1].ordershow();
         pl2 = m[ok1].ordershow();
         at1 = m[tp1].attackshow();
         at2 = m[ok1].attackshow();
         df1 = m[tp1].defenceshow();
         df2 = m[ok1].defenceshow();
         ps1 = m[tp1].passingshow();
         ps2 = m[ok1].passingshow();
         shoot1 = m[tp1].shootingshow();
         shoot2 = m[ok1].shootingshow();
         cs1 = m[tp1].capacityshow();
         cs2 = m[ok1].capacityshow();

         lg1 = leagueposition(3,pl1);
         lg2 = leagueposition(3,pl2);


       cout << endl << endl << "CONFEDERACY 2   " << team1 << "(" << lg1 << ")" << "  VS  " << team2 << "(" << lg2 << ")  at: " << stadium << "  cap:" << cs1 << endl;

        chrono::seconds dura(5);
        this_thread::sleep_for(dura);

       tp2 = 0;
       ok2 = 0;
       shotsongoal1 = 0;
       shotsongoal2 = 0;
       posesion1 = 0;
       posesion2 = 0;



       if (cs1 > cs2)
       {
          bigadvantage = (cs1 - cs2) / SUPERIORITY_LOWER_LOWER;
          ps1 = ps1 + bigadvantage;
       }

       if (cs2 > cs1)
       {
          bigadvantage = (cs2 - cs1) / SUPERIORITY_LOWER_LOWER;
          ps2 = ps2 + bigadvantage;
       }



    for(p = 0; p < 90; p++)
    {

      homeadvantage = rand() % 11 + 2;
      at0 = rand() % 151;
      df0 = rand() % 101 + 100;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + 100;
      ps4 = rand() % 151;



      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;

      totalpassing1 = totalpassing1 + homeadvantage;
      ver = rand() % 101;


     if(totalpassing1 >= totalpassing2)
      {
          posesion1 = posesion1 + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1 = shotsongoal1 + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             }
          }
        }
      }


      if(totalpassing2 > totalpassing1)
      {
          posesion2 = posesion2 + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2 = shotsongoal2 + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             }
          }
        }
      }
      if(p == 45)
       {
          ht1 = tp2;
          ht2 = ok2;
       }

    }





         cout << endl << endl << "             FINAL RESULT" << endl;
         cout << endl << endl << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;

         recm << right << setw(20) << team1 << " " << tp2 << right << setw(20) << team2 << " " << ok2 << "  HT:" << ht1 << "-" << ht2 << right << setw(20) << "SHOTS ON GOAL: "
         << right << setw(4) << shotsongoal1 << "   - " << right << setw(4) << shotsongoal2 << right << setw(20) << "POSSESION: "
         << right << setw(4) << posesion1 << "   - " << right << setw(4) << posesion2 << endl;


        m[tp1].changeplayed();
        m[ok1].changeplayed();
        m[tp1].changegoalsfor(tp2);
        m[ok1].changegoalsfor(ok2);
        m[tp1].changegoalsags(ok2);
        m[ok1].changegoalsags(tp2);
        m[tp1].changegoaldiff();
        m[ok1].changegoaldiff();

        if(tp2 > ok2)
        {
            m[tp1].givepoints(3);
            m[tp1].changewindrawloss(1);
            m[ok1].changewindrawloss(3);

        }
        if(tp2 < ok2)
        {
           m[ok1].givepoints(3);
           m[tp1].changewindrawloss(3);
           m[ok1].changewindrawloss(1);
        }

        if(tp2 == ok2)
        {
           m[tp1].givepoints(1);
           m[ok1].givepoints(1);
           m[tp1].changewindrawloss(2);
           m[ok1].changewindrawloss(2);
        }


        m[tp1].changebalance(cs1);
        m[ok1].changebalance(cs1 / 4);




    gm.open("TEAMS.BIN",ios_base::binary|ios_base::out);
        if(gm.fail())
        {
          cout << "Could not open teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }


        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
        {
          m[p].save(gm);
        }

       gm.close();

      lg1 = leagueposition(3,pl1);
      lg2 = leagueposition(3,pl2);

      cout << "        " << lg1 << "  League Position  " << lg2 << endl;
      cout << "  HT:" << ht1 << "-" << ht2 << "  SHOTS ON GOAL: " << shotsongoal1 << "-" << shotsongoal2 << right << "  POSSESION: " << posesion1 << "-" << posesion2 << endl << endl;

      this_thread::sleep_for(dura);



       fixes.turnplus();

       fixes.plusonegamenumber();

       fx.open("TWOCONFIXTURES.BIN",ios_base::binary|ios_base::out);
        if(fx.fail())
        {
          cout << "Could not open fixtures file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

     fixes.save(fx);






    cout << endl << endl;

        delete [] m;

//       m = nullptr;

       fx.close();

       recm.close();


    return;
}
