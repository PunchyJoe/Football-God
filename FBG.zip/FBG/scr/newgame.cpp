#include "footballgod.h"

void newgame(void)
{

  fstream yn;
  fstream gm;
  fstream fx;
  fstream fx2;
  fstream fx3;
  fstream fx4;
  fstream ledg;
  fstream recm;
  fstream finan;
  fstream notes;

  char wantcon;
  int p;



//  vector<team> igm (NUM_OF_TEAMS_TOTAL);

  fixtureselite ftr;
  fixturesconone ftr2;
  fixturescontwo ftr3;
  cup pups;


  int year = 3000;





  cout << " Selecting a New Game will reset the game back to the start" << endl
  << " - All previous games and data will be deleted and lost for ever." << endl
  << " Do You want to continue? Y/N" << endl;
  cin  >> wantcon;

  if(wantcon != 'Y' && wantcon != 'y')
  {
     return;
  }

  team* igm = new team[NUM_OF_TEAMS_TOTAL];


  gm.open("TEAMS.BIN",ios_base::binary|ios_base::out);
        if(gm.fail())
        {
          cout << "Could not open teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }



  for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
  {


        igm[p].nameteamname(p);

        igm[p].makenewteam(p);

        cout << "Creating Team........" << p+1 << endl;
        chrono::seconds dura(5);
        this_thread::sleep_for(dura);

        igm[p].save(gm);

  }


        gm.close();

        cout << endl << endl;


       fx.open("ELITEFIXTURES.BIN",ios_base::binary|ios_base::out);
        if(fx.fail())
        {
          cout << "Could not open fixtures file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        ftr.save(fx);

        fx.close();

        fx2.open("ONECONFIXTURES.BIN",ios_base::binary|ios_base::out);
        if(fx2.fail())
        {
          cout << "Could not open fixtures file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        ftr2.save(fx2);

        fx2.close();

        fx3.open("TWOCONFIXTURES.BIN",ios_base::binary|ios_base::out);
        if(fx3.fail())
        {
          cout << "Could not open fixtures file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        ftr3.save(fx3);

        fx3.close();

        fx4.open("CUP.BIN",ios_base::binary|ios_base::out);
        if(fx4.fail())
        {
          cout << "Could not open cup file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

          pups.save(fx4);


          fx4.close();

        yn.open("YEAR.BIN",ios_base::binary|ios_base::out);
        if(yn.fail())
        {
          cout << "Could not open Year file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        yn.write((char *)&year, sizeof(year));

        yn.close();


            ledg.open("ELITERESULTS.txt",ios_base::out);
            if (ledg.fail())
                {
                    cout << "ERROR: Cannot open the file..." << endl;
                    exit(1);
                }


          ledg.close();

           ledg.open("ONECONRESULTS.txt",ios_base::out);
            if (ledg.fail())
                {
                    cout << "ERROR: Cannot open the file..." << endl;
                    exit(1);
                }


          ledg.close();

          ledg.open("TWOCONRESULTS.txt",ios_base::out);
            if (ledg.fail())
                {
                    cout << "ERROR: Cannot open the file..." << endl;
                    exit(1);
                }

         ledg.close();


        recm.open("CUPRESULTS.txt",ios_base::out);
        if(recm.fail())
        {
          cout << "Could not open Cup Results file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        recm.close();







        recm.open("SEASONELITE.txt",ios_base::out);
        if(recm.fail())
        {
          cout << "Could not open season elite table file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        recm.close();

        recm.open("SEASONCONONE.txt",ios_base::out);
        if(recm.fail())
        {
          cout << "Could not open confederate 1 table file file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }
        recm.close();

        recm.open("SEASONCONTWO.txt",ios_base::out);
        if(recm.fail())
        {
          cout << "Could not open confederate 2 table file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        recm.close();

        finan.open("FINANCE.txt",ios_base::out);
        if(finan.fail())
        {
          cout << "Could not open season elite table file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        finan.close();

         notes.open("CLUBNOTES.txt",ios_base::out);
        if(notes.fail())
        {
          cout << "Could not open Cup Results file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        notes.close();

      delete [] igm;

//       igm = nullptr;


      cout << "New Game Created Successfully!!!" << endl << endl << endl;

      (void)_getch();

      exit(1);
}
