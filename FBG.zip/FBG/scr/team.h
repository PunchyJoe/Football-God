#ifndef TEAM_H_INCLUDED
#define TEAM_H_INCLUDED
#include <fstream>

using namespace std;

class team
{
    int order;
    int number;
    int division;
    int balance;
    int spent;
    int income;
    int capacity;
    char name[80];
    char stadium[80];
    char region[10];
    int attack;
    int defence;
    int passing;
    int shooting;
    int played;
    int wins;
    int draws;
    int loses;
    int points;
    int goalsfor;
    int goalsags;
    int gd;

    public:
    team();
    ~team();

    void nameteamname(int n);
    void makenewteam(int n);
    void showteamsshow();
    void showteams();
    void resetstats();
    void sortmoney(int syear);
    void teamchanges(int syear);
    void sackmanager(int syear);
    void incapacity(int syear);
    void intocredit(int syear);
    void intodebit(int syear);
    void promo(int swhat);
    void givepoints(int gip);
    void changeplayed();
    void changewindrawloss(int cs);
    void changegoalsfor(int cs);
    void changegoalsags(int cs);
    void changegoaldiff();
    void changenumber(int zz);
    void changebalance(int cs);
    void showendteams(fstream & filein);
    void showfinance(fstream & filein);
    void swapshowteam(const char *mn, const char *sn, const char *rn, int pdd, int a, int rt, int brt);
    void swapteam(const char *mn, int pdd, int a, int rt, int brt, int gsf, int gsa, int gddd, int ppp);
    void swapteampos(const char *mn, int pdd, int gsf, int gsa, int gddd, int ppp);
    void swapteampromo(const char *mn, const char *sn, const char *rn, int pdd, int a, int rt, int brt, int gsf, int gsa, int gddd, int ppp, int ogg, int tatt, int tdef, int tpass, int tshoot, int capt, int balt);
    void teamshow(char *mn);
    void stadiumshow(char *mn);
    void regionshow(char *mn);
    int sellsellsell(int syear);
    int attackshow();
    int defenceshow();
    int passingshow();
    int shootingshow();
    int capacityshow();
    int balanceshow();
    int spentshow();
    int incomeshow();
    int ordershow();
    int numbershow();
    int showdivision();
    int showplayed();
    int showwins();
    int showdraws();
    int showloses();
    int showgoalsfor();
    int showgoalsags();
    int showpoints();
    int showgoaldiff();


    void save(fstream& op);
    int load(fstream& ip);
};

#endif // TEAM_H_INCLUDED
