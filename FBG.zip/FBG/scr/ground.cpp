#include "footballgod.h"



void ground(void)
{

      fstream gm;
      fstream yn;
      fstream fx;

      char sitdown[4];
      char wantcon;

      int u = 1;
      int p, e;
      int teamcap;
      int year;
      int ok1;
      int funds;

      fixturescontwo fixes3;

       srand ( (unsigned int)time(NULL) );

      yn.open("YEAR.BIN",ios_base::binary|ios_base::in);
        if(yn.fail())
        {
          cout << "Could not open Year file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        yn.read((char *)&year, sizeof(year));

        yn.close();

        if(year < 3005)
        {
          cout << "Cannot increase capacity yet wait for year 3005" << endl;
          (void)_getch();
          return;
        }




        fx.open("TWOCONFIXTURES.BIN",ios::binary|ios::in);
        if(fx.fail())
        {
          cout << "Could not open fictures file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        fixes3.load(fx);

        fx.close();

        ok1 = fixes3.checkgamenumber();


     if(ok1 > 1)
      {
       cout << "Cannot increase capacity while season in progress" << endl;
       (void)_getch();
       return;
      }




       cout << "Increasing capacity will cost 5000000 per 1000 seats(Confederacy 2 not applicable)." << endl;
       cout << " Do You want to continue? Y/N" << endl;
       cin  >> wantcon;

       if(wantcon != 'Y' && wantcon != 'y')
       {
         return;
       }



       team* igm = new team[NUM_OF_TEAMS_TOTAL];

       gm.open("TEAMS.BIN",ios_base::binary|ios_base::in);
        if(gm.fail())
        {
          cout << "Could not open teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }


        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
         {
            igm[p].load(gm);
         }

        gm.close();






         cout << "                        ATLANTIS ALL TEAMS                              " << endl;
         cout << "------------------------------------------------------------------------" << endl;
         cout << "                         Div  Reg        Bal                  Sta(cap)  " << endl;
         cout << "------------------------------------------------------------------------" << endl;


         for (e = 0; e < (NUM_OF_TEAMS_TOTAL - 18); e++)
         {

           cout << "# " << setw(2) << u << "  ";
           igm[e].showteamsshow();
           u++;
         }

        do
        {
        cout << endl << " Input team number to increase seating capacity by 1000: " << endl;
        cin >> sitdown;
        teamcap = atoi(sitdown);
        cout << endl;

        }while(teamcap <= 0 || teamcap > 24);

        teamcap = teamcap - 1;

        funds = igm[teamcap].balanceshow();

        if(funds >= -15000000)
        {
        igm[teamcap].incapacity(year);
        cout << "The Below team increased seating capacity by 1000: " << endl;
        igm[teamcap].showteamsshow();

        gm.open("TEAMS.BIN",ios_base::binary|ios_base::out);
        if(gm.fail())
            {
               cout << "Could not open save teams file - Press a key" << endl;
               (void)_getch();
                exit(1);
            }

        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
            {
               igm[p].save(gm);
            }

        gm.close();
        }
        else
        {
           cout << "Team does not have sufficient funds" << endl;
        }


        delete [] igm;

        (void)_getch();

        return;


}
