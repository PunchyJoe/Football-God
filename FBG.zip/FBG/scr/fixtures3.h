#ifndef FIXTURESCONTWO_H_INCLUDED
#define FIXTURESCONTWO_H_INCLUDED
#include <fstream>

using namespace std;

class fixturescontwo
{

    int teamturn;
    int gamenumber;
    char week[17];
    char teamvteam24[17];
    char teamvteam25[17];
    char teamvteam26[17];
    char teamvteam27[17];
    char teamvteam28[17];
    char teamvteam29[17];
    char teamvteam30[17];
    char teamvteam31[17];
    char teamvteam32[17];
    char teamvteam33[17];
    char teamvteam34[17];
    char teamvteam35[17];
    char teamvteam36[17];
    char teamvteam37[17];
    char teamvteam38[17];
    char teamvteam39[17];

    public:
    fixturescontwo();
    ~fixturescontwo();


    int teamchecker(int tc1);
    int checkturn();
    int checkturntwo();
    int checkgamenumber();
    void plusonegamenumber();
    void fullseasonthree();
    void turnplus();


    void save(fstream& op);
    int load(fstream& ip);
};
#endif // FIXTURESCONTWO_H_INCLUDED
