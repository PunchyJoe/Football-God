#include "footballgod.h"



void show(void)
{
        fstream gm;
        int p, j, u, e;
        int pl1, pl2, di1, di2;
        int gf1, gf2, ga1, ga2;
        char mst1[80];
        char mst2[80];
        char sst1[80];
        char sst2[80];
        char rst1[10];
        char rst2[10];
        char gamechoice;


  cout << "                         FOOTBALL GOD" << endl << endl;
  cout << "                         SORT BY:" << endl << endl;
  cout << "                          A.Number" << endl;
  cout << "                          B.Balance" << endl;
  cout << "                          C.Capacity" << endl;
  cout << "                          D.Division" << endl;


      cin  >> gamechoice;

      gamechoice = tolower(gamechoice);


        gm.open("TEAMS.BIN",ios_base::binary|ios_base::in);
        if(gm.fail())
        {
          cout << "Could not open Teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

         team* igm = new team[NUM_OF_TEAMS_TOTAL];

//        vector<team> igm (NUM_OF_TEAMS_TOTAL);

        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
         {
           igm[p].load(gm);
         }

        gm.close();


        cout << endl << endl << endl;

     if(gamechoice == 'a' )
     {


           for (p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
            {
              for (j = 0; j < (NUM_OF_TEAMS_TOTAL - 1); j++)
               {

                 igm[j].teamshow(mst1);
                 igm[j+1].teamshow(mst2);
                 igm[j].stadiumshow(sst1);
                 igm[j+1].stadiumshow(sst2);
                 igm[j].regionshow(rst1);
                 igm[j+1].regionshow(rst2);
                 pl1  = igm[j].ordershow();
                 pl2  = igm[j+1].ordershow();
                 gf1 = igm[j].balanceshow();
                 gf2 = igm[j+1].balanceshow();
                 ga1 = igm[j].capacityshow();
                 ga2 = igm[j+1].capacityshow();
                 di1 = igm[j].showdivision();
                 di2 = igm[j+1].showdivision();



                 if (pl2 < pl1)
                  {
                    igm[j].swapshowteam(mst2,sst2,rst2,pl2,gf2,ga2,di2);
                    igm[j+1].swapshowteam(mst1,sst1,rst1,pl1,gf1,ga1,di1);
                  }

              }
            }



         u = 1;



         cout << "                        ATLANTIS ALL TEAMS                              " << endl;
         cout << "------------------------------------------------------------------------" << endl;
         cout << "                         Div  Reg        Bal                  Sta(cap)  " << endl;
         cout << "------------------------------------------------------------------------" << endl;


         for (e = 0; e < NUM_OF_TEAMS_TOTAL; e++)
         {

           cout << "# " << setw(2) << u << "  ";
           igm[e].showteamsshow();
           u++;
         }


     }





     if(gamechoice == 'b' )
     {


          for (p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
            {
              for (j = 0; j < (NUM_OF_TEAMS_TOTAL - 1); j++)
               {

                 igm[j].teamshow(mst1);
                 igm[j+1].teamshow(mst2);
                 igm[j].stadiumshow(sst1);
                 igm[j+1].stadiumshow(sst2);
                 igm[j].regionshow(rst1);
                 igm[j+1].regionshow(rst2);
                 pl1  = igm[j].numbershow();
                 pl2  = igm[j+1].numbershow();
                 gf1 = igm[j].balanceshow();
                 gf2 = igm[j+1].balanceshow();
                 ga1 = igm[j].capacityshow();
                 ga2 = igm[j+1].capacityshow();
                 di1 = igm[j].showdivision();
                 di2 = igm[j+1].showdivision();



                 if (gf1 < gf2)
                  {
                    igm[j].swapshowteam(mst2,sst2,rst2,pl2,gf2,ga2,di2);
                    igm[j+1].swapshowteam(mst1,sst1,rst1,pl1,gf1,ga1,di1);
                  }

              }
            }



         u = 1;



         cout << "                        ATLANTIS ALL TEAMS                              " << endl;
         cout << "------------------------------------------------------------------------" << endl;
         cout << "                         Div  Reg        Bal                  Sta(cap)  " << endl;
         cout << "------------------------------------------------------------------------" << endl;


         for (e = 0; e < NUM_OF_TEAMS_TOTAL; e++)
         {

           cout << "# " << setw(2) << u << "  ";
           igm[e].showteamsshow();
           u++;
         }


     }






    if(gamechoice == 'c' )
     {


           for (p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
            {
              for (j = 0; j < (NUM_OF_TEAMS_TOTAL - 1); j++)
               {

                 igm[j].teamshow(mst1);
                 igm[j+1].teamshow(mst2);
                 igm[j].stadiumshow(sst1);
                 igm[j+1].stadiumshow(sst2);
                 igm[j].regionshow(rst1);
                 igm[j+1].regionshow(rst2);
                 pl1  = igm[j].numbershow();
                 pl2  = igm[j+1].numbershow();
                 gf1 = igm[j].balanceshow();
                 gf2 = igm[j+1].balanceshow();
                 ga1 = igm[j].capacityshow();
                 ga2 = igm[j+1].capacityshow();
                 di1 = igm[j].showdivision();
                 di2 = igm[j+1].showdivision();



                 if (ga1 < ga2)
                  {
                    igm[j].swapshowteam(mst2,sst2,rst2,pl2,gf2,ga2,di2);
                    igm[j+1].swapshowteam(mst1,sst1,rst1,pl1,gf1,ga1,di1);
                  }

              }
            }



         u = 1;



         cout << "                        ATLANTIS ALL TEAMS                              " << endl;
         cout << "------------------------------------------------------------------------" << endl;
         cout << "                         Div  Reg        Bal                  Sta(cap)  " << endl;
         cout << "------------------------------------------------------------------------" << endl;


         for (e = 0; e < NUM_OF_TEAMS_TOTAL; e++)
         {

           cout << "# " << setw(2) << u << "  ";
           igm[e].showteamsshow();
           u++;
         }


     }




     if(gamechoice == 'd' )
     {


           for (p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
            {
              for (j = 0; j < (NUM_OF_TEAMS_TOTAL - 1); j++)
               {

                 igm[j].teamshow(mst1);
                 igm[j+1].teamshow(mst2);
                 igm[j].stadiumshow(sst1);
                 igm[j+1].stadiumshow(sst2);
                 igm[j].regionshow(rst1);
                 igm[j+1].regionshow(rst2);
                 pl1  = igm[j].numbershow();
                 pl2  = igm[j+1].numbershow();
                 gf1 = igm[j].balanceshow();
                 gf2 = igm[j+1].balanceshow();
                 ga1 = igm[j].capacityshow();
                 ga2 = igm[j+1].capacityshow();
                 di1 = igm[j].showdivision();
                 di2 = igm[j+1].showdivision();



                 if (di2 < di1)
                  {
                    igm[j].swapshowteam(mst2,sst2,rst2,pl2,gf2,ga2,di2);
                    igm[j+1].swapshowteam(mst1,sst1,rst1,pl1,gf1,ga1,di1);
                  }

              }
            }



         u = 1;



         cout << "                        ATLANTIS ALL TEAMS                              " << endl;
         cout << "------------------------------------------------------------------------" << endl;
         cout << "                         Div  Reg        Bal                  Sta(cap)  " << endl;
         cout << "------------------------------------------------------------------------" << endl;


         for (e = 2; e < NUM_OF_TEAMS_TOTAL; e++)
         {

           cout << "# " << setw(2) << u << "  ";
           igm[e].showteamsshow();
           u++;
         }


     }







       cout << endl << endl;

       delete [] igm;

//       igm = nullptr;


        (void)_getch();

        return;


}
