#include "footballgod.h"


int leagueposition(int ddd,int ttt)
{
        fstream gm;
        int tpoints1, tpoints2, goaldiff1, goaldiff2, p, j, u, e;
        int pl1, pl2;
        int gf1, gf2, ga1, ga2;
        int snap;
        char mst1[80];
        char mst2[80];


        gm.open("TEAMS.BIN",ios_base::binary|ios_base::in);
        if(gm.fail())
        {
          cout << "Could not open Teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

         team* igm = new team[NUM_OF_TEAMS_TOTAL];

        // vector<team> igm (NUM_OF_TEAMS_TOTAL);

        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
         {
           igm[p].load(gm);
         }

        gm.close();





if(ddd == 1)
{



           for (p = 0; p <= 7; p++)
            {
              for (j = 0; j <= 6; j++)
               {

                 tpoints1  = igm[j].showpoints();
                 tpoints2 = igm[j+1].showpoints();
                 igm[j].teamshow(mst1);
                 igm[j+1].teamshow(mst2);
                 pl1  = igm[j].ordershow();
                 pl2  = igm[j+1].ordershow();
                 gf1 = igm[j].showgoalsfor();
                 gf2 = igm[j+1].showgoalsfor();
                 ga1 = igm[j].showgoalsags();
                 ga2 = igm[j+1].showgoalsags();
                 goaldiff1  = igm[j].showgoaldiff();
                 goaldiff2  = igm[j+1].showgoaldiff();



                 if (tpoints1 < tpoints2)
                  {
                    igm[j].swapteampos(mst2,pl2,gf2,ga2,goaldiff2,tpoints2);
                    igm[j+1].swapteampos(mst1,pl1,gf1,ga1,goaldiff1,tpoints1);
                  }

                  if (tpoints1 == tpoints2)
                   {
                        if (goaldiff1 < goaldiff2)
                        {
                           igm[j].swapteampos(mst2,pl2,gf2,ga2,goaldiff2,tpoints2);
                           igm[j+1].swapteampos(mst1,pl1,gf1,ga1,goaldiff1,tpoints1);
                        }

                        if (goaldiff1 == goaldiff2)
                       {
                          if (gf1 < gf2)
                           {
                              igm[j].swapteampos(mst2,pl2,gf2,ga2,goaldiff2,tpoints2);
                              igm[j+1].swapteampos(mst1,pl1,gf1,ga1,goaldiff1,tpoints1);
                           }

                          if (gf1 == gf2)
                          {
                               if (ga1 > ga2)
                                {
                                igm[j].swapteampos(mst2,pl2,gf2,ga2,goaldiff2,tpoints2);
                                igm[j+1].swapteampos(mst1,pl1,gf1,ga1,goaldiff1,tpoints1);
                                }
                          }
                      }
                 }
              }
            }



         u = 1;



         for (e = 0; e <= 7; e++)
         {
           snap =  igm[e].ordershow();
           if(ttt == snap)
           {
             delete [] igm;
             return u;
           }
           u++;
         }

}




if(ddd == 2)
{



           for (p = 8; p <= 23; p++)
            {
              for (j = 8; j <= 22; j++)
               {

                 tpoints1  = igm[j].showpoints();
                 tpoints2 = igm[j+1].showpoints();
                 igm[j].teamshow(mst1);
                 igm[j+1].teamshow(mst2);
                 pl1  = igm[j].ordershow();
                 pl2  = igm[j+1].ordershow();
                 gf1 = igm[j].showgoalsfor();
                 gf2 = igm[j+1].showgoalsfor();
                 ga1 = igm[j].showgoalsags();
                 ga2 = igm[j+1].showgoalsags();
                 goaldiff1  = igm[j].showgoaldiff();
                 goaldiff2  = igm[j+1].showgoaldiff();



                 if (tpoints1 < tpoints2)
                  {
                    igm[j].swapteampos(mst2,pl2,gf2,ga2,goaldiff2,tpoints2);
                    igm[j+1].swapteampos(mst1,pl1,gf1,ga1,goaldiff1,tpoints1);
                  }

                  if (tpoints1 == tpoints2)
                   {
                        if (goaldiff1 < goaldiff2)
                        {
                           igm[j].swapteampos(mst2,pl2,gf2,ga2,goaldiff2,tpoints2);
                           igm[j+1].swapteampos(mst1,pl1,gf1,ga1,goaldiff1,tpoints1);
                        }

                        if (goaldiff1 == goaldiff2)
                       {
                          if (gf1 < gf2)
                           {
                              igm[j].swapteampos(mst2,pl2,gf2,ga2,goaldiff2,tpoints2);
                              igm[j+1].swapteampos(mst1,pl1,gf1,ga1,goaldiff1,tpoints1);
                           }

                          if (gf1 == gf2)
                          {
                               if (ga1 > ga2)
                                {
                                igm[j].swapteampos(mst2,pl2,gf2,ga2,goaldiff2,tpoints2);
                                igm[j+1].swapteampos(mst1,pl1,gf1,ga1,goaldiff1,tpoints1);
                                }
                          }
                      }
                 }
              }
            }



         u = 1;



         for (e = 8; e <= 23; e++)
         {
           snap =  igm[e].ordershow();
           if(ttt == snap)
           {
             delete [] igm;
             return u;
           }
           u++;
         }

}




if(ddd == 3)
{



           for (p = 24; p <= 39; p++)
            {
              for (j = 24; j <= 38; j++)
               {

                 tpoints1  = igm[j].showpoints();
                 tpoints2 = igm[j+1].showpoints();
                 igm[j].teamshow(mst1);
                 igm[j+1].teamshow(mst2);
                 pl1  = igm[j].ordershow();
                 pl2  = igm[j+1].ordershow();
                 gf1 = igm[j].showgoalsfor();
                 gf2 = igm[j+1].showgoalsfor();
                 ga1 = igm[j].showgoalsags();
                 ga2 = igm[j+1].showgoalsags();
                 goaldiff1  = igm[j].showgoaldiff();
                 goaldiff2  = igm[j+1].showgoaldiff();



                 if (tpoints1 < tpoints2)
                  {
                    igm[j].swapteampos(mst2,pl2,gf2,ga2,goaldiff2,tpoints2);
                    igm[j+1].swapteampos(mst1,pl1,gf1,ga1,goaldiff1,tpoints1);
                  }

                  if (tpoints1 == tpoints2)
                   {
                        if (goaldiff1 < goaldiff2)
                        {
                           igm[j].swapteampos(mst2,pl2,gf2,ga2,goaldiff2,tpoints2);
                           igm[j+1].swapteampos(mst1,pl1,gf1,ga1,goaldiff1,tpoints1);
                        }

                        if (goaldiff1 == goaldiff2)
                       {
                          if (gf1 < gf2)
                           {
                              igm[j].swapteampos(mst2,pl2,gf2,ga2,goaldiff2,tpoints2);
                              igm[j+1].swapteampos(mst1,pl1,gf1,ga1,goaldiff1,tpoints1);
                           }

                          if (gf1 == gf2)
                          {
                               if (ga1 > ga2)
                                {
                                igm[j].swapteampos(mst2,pl2,gf2,ga2,goaldiff2,tpoints2);
                                igm[j+1].swapteampos(mst1,pl1,gf1,ga1,goaldiff1,tpoints1);
                                }
                          }
                      }
                 }
              }
            }



         u = 1;



         for (e = 24; e <= 39; e++)
         {
           snap =  igm[e].ordershow();
           if(ttt == snap)
           {
             delete [] igm;
             return u;
           }
           u++;
         }

}


       delete [] igm;

//       igm = nullptr;


        return 0;


}
