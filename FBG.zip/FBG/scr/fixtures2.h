#ifndef FIXTURES2_H_INCLUDED
#define FIXTURES2_H_INCLUDED
#include <fstream>

using namespace std;

class fixturesconone
{

    int teamturn;
    int gamenumber;
    char week[17];
    char teamvteam8[17];
    char teamvteam9[17];
    char teamvteam10[17];
    char teamvteam11[17];
    char teamvteam12[17];
    char teamvteam13[17];
    char teamvteam14[17];
    char teamvteam15[17];
    char teamvteam16[17];
    char teamvteam17[17];
    char teamvteam18[17];
    char teamvteam19[17];
    char teamvteam20[17];
    char teamvteam21[17];
    char teamvteam22[17];
    char teamvteam23[17];



    public:
    fixturesconone();
    ~fixturesconone();


    int teamchecker(int tc1);
    int checkturn();
    int checkturntwo();
    int checkgamenumber();
    void plusonegamenumber();
    void fullseasontwo();
    void turnplus();


    void save(fstream& op);
    int load(fstream& ip);
};
#endif // FIXTURES2_H_INCLUDED
