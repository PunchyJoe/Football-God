#include "footballgod.h"

void newgame(void);
void tableselite(void);
void tablesconone(void);
void tablescontwo(void);
void manager(void);
void ground(void);
void sellasetts(void);
void show(void);
void elitegame(void);
void congameone(void);
void congametwo(void);
void belitegame(void);
void bcongameone(void);
void bcongametwo(void);
void cupgame(void);
void promrelaga(void);

int main()
{

  fstream yn;
  int year = 0;
  char gamechoice;

  chrono::seconds dura(15);

        yn.open("YEAR.BIN",ios_base::binary|ios_base::in);
        if(yn.fail())
        {
        }

        yn.read((char *)&year, sizeof(year));

        yn.close();


        cout << "Version: " << __DATE__ << " " << __TIME__ << endl << endl;

 do
  {
  cout << endl << endl;
  cout << "                         FOOTBALL GOD" << endl << endl;
  cout << "                         Year: " << year << endl << endl;
  cout << "                         MAIN MENU:" << endl << endl;
  cout << "                          U.New Game" << endl;
  cout << "                          Q.All Teams" << endl;
  cout << "                          T.Tables" << endl;
  cout << "                          G.Sack Manager" << endl;
  cout << "                          I.Increase Ground Seating Capacity by 1000" << endl;
  cout << "                          X.Sell Club Assets" << endl;
  cout << "                          K.Carousel" << endl;
  cout << "                          C.Cup" << endl;
  cout << "                          S.Next Season" << endl;
  cout << "                          Z.Exit Game" << endl;

  cin  >> gamechoice;

      gamechoice = tolower(gamechoice);

	  switch(gamechoice)
	  {
		 case 'u': newgame();
		  break;
		 case 'q': show();
		  break;
         case 't': tablescontwo();(void)_getch();tablesconone();(void)_getch();tableselite();(void)_getch();
          break;
         case 'g': manager();
            break;
         case 'i': ground();
            break;
         case 'x': sellasetts();
            break;
         case 'k':
             do
             {
                  bcongametwo(); bcongametwo(); bcongametwo(); bcongametwo();
                  bcongametwo(); bcongametwo(); bcongametwo(); bcongametwo(); tablescontwo(); this_thread::sleep_for(dura);
                  bcongameone(); bcongameone(); bcongameone(); bcongameone();
                  bcongameone(); bcongameone(); bcongameone(); bcongameone(); tablesconone(); this_thread::sleep_for(dura);
                  belitegame(); belitegame(); belitegame(); belitegame(); tableselite();
                  cout << endl << endl << "SAFE TO TURN OFF HERE....." << endl; this_thread::sleep_for(dura);
             }while(1);
          break;
          case 'c': cupgame();
		  break;
          case 's': promrelaga();
          break;
         case 'z': return 0;
          break;
         default: return 0;
	  }
  }while(1);

      return 0;

}
