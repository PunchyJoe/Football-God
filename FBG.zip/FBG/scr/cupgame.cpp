#include "footballgod.h"

void cupgame(void)
{
  fstream gm;
  fstream fx;
  fstream recm;
  fstream yn;
  int shoot1, shoot2, ver, defoff, p, gn;
  int ok1, tp1, at1, df1, ps1;
  int ok2, tp2, at2, df2, ps2;
  int ook2 = 0;
  int ttp2 = 0;
  int fuckingpens = 0;
  int pennum = 0;
  int round, ct1, ct2, cs1, cs2;
  int at0, df0, ps0;
  int at4, df4, ps4;
  int ht1 = 0;
  int ht2 = 0;
  int ft1 = 0;
  int ft2 = 0;
  int totalattack1, totaldefence1, totalpassing1;
  int totalattack2, totaldefence2, totalpassing2;
  int shotsongoal1, shotsongoal2, shotsongoal1et, shotsongoal2et;
  int posesion1, posesion2, posesion1et, posesion2et;
  int homeadvantage, bigadvantage;
  int mins = 90;
  int year;
  int bub;
  char team1[80];
  char team2[80];
  char stadium[80];

  fixtureselite fixes;

  cup pups;

  srand ( (unsigned int)time(NULL) );




   fx.open("ELITEFIXTURES.BIN",ios_base::binary|ios_base::in);
   if(fx.fail())
        {
          cout << "Could not open teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

    fixes.load(fx);


    fx.close();


    fixes.plusonegamenumber();

    bub = fixes.checkgamenumber();


   if(bub < 113)
      {
        cout << "Union Elite season not over - Please play league matches first" << endl;
        (void)_getch();
        return;
      }






   yn.open("YEAR.BIN",ios_base::binary|ios_base::in);
        if(yn.fail())
        {
          cout << "Could not open Year file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

       yn.read((char *)&year, sizeof(year));

       yn.close();




   recm.open("CUPRESULTS.txt",ios_base::app | ios_base::out);
        if(recm.fail())
        {
          cout << "Could not open Cup Results file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }


  fx.open("CUP.BIN",ios_base::binary|ios_base::in);
        if(fx.fail())
        {
          cout << "Could not open cup file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

     pups.load(fx);


     fx.close();

   team* m = new team[NUM_OF_TEAMS_TOTAL];

  // vector<team> m (NUM_OF_TEAMS_TOTAL);




  gm.open("TEAMS.BIN",ios_base::binary|ios_base::in);
        if(gm.fail())
        {
          cout << "Could not open teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }


  for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
  {
      m[p].load(gm);
  }

    gm.close();















     round = pups.roundchecker();









if(round == 1)
    {

    gn = pups.showgamenumber();


    do{

       do{
       ct1 = rand() % 32 + 8;
       tp1 = pups.teamchecker(ct1,1);
       }while(tp1 == 100);

       do{
       ct2 = rand() % 32 + 8;
       ok1 = pups.teamchecker(ct2,1);
       }while(ok1 == 100);




       }while(tp1 == ok1);




         m[tp1].teamshow(team1);
         m[ok1].teamshow(team2);
         m[tp1].stadiumshow(stadium);
         at1 = m[tp1].attackshow();
         at2 = m[ok1].attackshow();
         df1 = m[tp1].defenceshow();
         df2 = m[ok1].defenceshow();
         ps1 = m[tp1].passingshow();
         ps2 = m[ok1].passingshow();
         shoot1 = m[tp1].shootingshow();
         shoot2 = m[ok1].shootingshow();
         cs1 = m[tp1].capacityshow();
         cs2 = m[ok1].capacityshow();


       cout << endl << endl << right << setw(2) << gn << "ROUND 1 ALL ATLANTIS CUP:   " << team1 << "  VS  " << team2 << "  at: " << stadium << "  cap:" << cs1 << endl;
       (void)_getch();

       tp2 = 0;
       ok2 = 0;
       shotsongoal1 = 0;
       shotsongoal2 = 0;
       posesion1 = 0;
       posesion2 = 0;

       if (cs1 > cs2)
       {
          bigadvantage = (cs1 - cs2) / CUPSUPERIORITY;
          ps1 = ps1 + bigadvantage;
       }

       if (cs2 > cs1)
       {
          bigadvantage = (cs2 - cs1) / CUPSUPERIORITY;
          ps2 = ps2 + bigadvantage;
       }



        for(p = 0; p < 90; p++)
        {

      homeadvantage = rand() % 11 + 2;
      at0 = rand() % 151;
      df0 = rand() % 101 + 100;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + 100;
      ps4 = rand() % 151;




      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;

      totalpassing1 = totalpassing1 + homeadvantage;
      ver = rand() % 101;





     if(totalpassing1 >= totalpassing2)
      {
          posesion1 = posesion1 + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1 = shotsongoal1 + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             }
          }
        }
      }



       if(totalpassing2 > totalpassing1)
      {
          posesion2 = posesion2 + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2 = shotsongoal2 + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             }
          }
        }
      }
      if(p == 45)
       {
          ht1 = tp2;
          ht2 = ok2;
       }
  }

     if(tp2 == ok2)
       {
      chrono::seconds dura(1);
      this_thread::sleep_for(dura);
      p = 90;
      defoff = 100;
      shotsongoal1et = 0;
      shotsongoal2et = 0;
      posesion1et = 0;
      posesion2et = 0;
      ft1 = tp2;
      ft2 = ok2;

      do{

      homeadvantage = rand() % 11 + 2;
      at0 = rand() % 151;
      df0 = rand() % 101 + defoff;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + defoff;
      ps4 = rand() % 151;

      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;

      totalpassing1 = totalpassing1 + homeadvantage;
      ver = rand() % 101;


     if(totalpassing1 >= totalpassing2)
      {
          posesion1et = posesion1et + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1et = shotsongoal1et + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             }
          }
        }
      }


      if(totalpassing2 > totalpassing1)
      {
          posesion2et = posesion2et + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2et = shotsongoal2et + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             }
          }
        }
      }
         p++;
         mins++;
         if(defoff > 0)
         {
            --defoff;
         }
        }while(p <= 119);

        if(tp2 == ok2 && p > 119)
        {
            fuckingpens = 1;
            while(ttp2 == ook2)
            {
                ver = rand() % 201;
                if(shoot1 < ver)
                {
                  ttp2 = ttp2 + 1;
                }

                ver = rand() % 201;
                if(shoot2 < ver)
                {
                  ook2 = ook2 + 1;
                }
            }
        }


       }

        cout << "  FULL TIME - Press a key" << endl;
        (void)_getch();

         cout << endl << endl << "             FINAL RESULT" << endl;
         cout << endl << endl << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
         cout << "  HT:" << ht1 << "-" << ht2 << "  SHOTS ON GOAL: " << shotsongoal1 << "-" << shotsongoal2 << right
         << "  POSSESION: " << posesion1 << "-" << posesion2 << endl;

         recm << year << " " << right << setw(2) << gn << "R1: " << right << setw(20) << team1 << " " << tp2 << right << setw(20) << team2 << " " << ok2 << "  HT:" << ht1 << "-" << ht2 << right << setw(20) << "SHOTS ON GOAL: "
         << right << setw(4) << shotsongoal1 << "   - " << right << setw(4) << shotsongoal2 << right << setw(20) << "POSSESION: "
         << right << setw(4) << posesion1 << "   - " << right << setw(4) << posesion2;

         if(mins > 90)
         {
            recm << "  A.E.T ";
            cout << "  A.E.T ";
            if(fuckingpens == 1)
            {
            recm << right << setw(10)<< "PENS: " << ttp2 << "-" << ook2 << "  FT:" << ft1 << "-" << ft2 << setw(20) << "ETSHOTS: "
             << right << setw(4) << shotsongoal1et << "   - " << right << setw(4) << shotsongoal2et << right << setw(10) << "ETPOS: "
             << right << setw(4) << posesion1et << "   - " << right << setw(4) << posesion2et;
            cout << "  PENS: " << ttp2 << "-" << ook2 << "  FT:" << ft1 << "-" << ft2 << "  ETSHOTS: "
             << shotsongoal1et << " - " << shotsongoal2et << "  ETPOS: " << posesion1et << " - " << posesion2et;
            }
            else
            {
            recm << right << setw(18)<< "FT:" << ft1 << "-" << ft2 << setw(20) << "ETSHOTS: "
            << right << setw(4) << shotsongoal1et << "   - " << right << setw(4) << shotsongoal2et << right << setw(10) << "ETPOS: "
            << right << setw(4) << posesion1et << "   - " << right << setw(4) << posesion2et;
            cout << "  FT:" << ft1 << "-" << ft2 << "  ETSHOTS: " << shotsongoal1et << " - " << shotsongoal2et << "  ETPOS: "
            << posesion1et << " - " << posesion2et;
            }

            recm << endl;
            cout << endl;
         }
        else
         {
            recm << endl;
            cout << endl;
         }

        tp2 = tp2 + ttp2;
        ok2 = ok2 + ook2;


        if(tp2 > ok2)
        {
            m[tp1].changebalance(1000);
            pups.teamwonlost(tp1,2);
            pups.teamwonlost(ok1,0);
        }
        if(tp2 < ok2)
        {
            m[ok1].changebalance(1000);
            pups.teamwonlost(tp1,0);
            pups.teamwonlost(ok1,2);
        }






         if(gn == 16)
         {
             pups.resetgamenumber();
         }
         else
         {
            pups.gamenumberplusone();
         }





    }//first round end













    else if(round == 2)
    {

      gn = pups.showgamenumber();

    do{

       do{
       ct1 = rand() % 32 + 8;
       tp1 = pups.teamchecker(ct1,2);
       }while(tp1 == 100);

       do{
       ct2 = rand() % 32 + 8;
       ok1 = pups.teamchecker(ct2,2);
       }while(ok1 == 100);




       }while(tp1 == ok1);




         m[tp1].teamshow(team1);
         m[ok1].teamshow(team2);
         m[tp1].stadiumshow(stadium);
         at1 = m[tp1].attackshow();
         at2 = m[ok1].attackshow();
         df1 = m[tp1].defenceshow();
         df2 = m[ok1].defenceshow();
         ps1 = m[tp1].passingshow();
         ps2 = m[ok1].passingshow();
         shoot1 = m[tp1].shootingshow();
         shoot2 = m[ok1].shootingshow();
         cs1 = m[tp1].capacityshow();
         cs2 = m[ok1].capacityshow();


       cout << endl << endl << right << setw(2) << gn << "ROUND 2 ALL ATLANTIS CUP:   " << team1 << "  VS  " << team2 << "  at: " << stadium << "  cap:" << cs1 << endl;
       (void)_getch();

       tp2 = 0;
       ok2 = 0;
       shotsongoal1 = 0;
       shotsongoal2 = 0;
       posesion1 = 0;
       posesion2 = 0;


       if (cs1 > cs2)
       {
          bigadvantage = (cs1 - cs2) / CUPSUPERIORITY;
          ps1 = ps1 + bigadvantage;
       }

       if (cs2 > cs1)
       {
          bigadvantage = (cs2 - cs1) / CUPSUPERIORITY;
          ps2 = ps2 + bigadvantage;
       }



        for(p = 0; p < 90; p++)
        {

      homeadvantage = rand() % 11 + 2;
      at0 = rand() % 151;
      df0 = rand() % 101 + 100;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + 100;
      ps4 = rand() % 151;




      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;

      totalpassing1 = totalpassing1 + homeadvantage;
      ver = rand() % 101;





     if(totalpassing1 >= totalpassing2)
      {
          posesion1 = posesion1 + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1 = shotsongoal1 + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             }
          }
        }
      }



       if(totalpassing2 > totalpassing1)
      {
          posesion2 = posesion2 + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2 = shotsongoal2 + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             }
          }
        }
      }
      if(p == 45)
       {
          ht1 = tp2;
          ht2 = ok2;
       }
  }

     if(tp2 == ok2)
       {
      chrono::seconds dura(1);
      this_thread::sleep_for(dura);
      p = 90;
      defoff = 100;
      shotsongoal1et = 0;
      shotsongoal2et = 0;
      posesion1et = 0;
      posesion2et = 0;
      ft1 = tp2;
      ft2 = ok2;

      do{

      homeadvantage = rand() % 11 + 2;
      at0 = rand() % 151;
      df0 = rand() % 101 + defoff;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + defoff;
      ps4 = rand() % 151;



      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;

      totalpassing1 = totalpassing1 + homeadvantage;
      ver = rand() % 101;


     if(totalpassing1 >= totalpassing2)
      {
          posesion1et = posesion1et + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1et = shotsongoal1et + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             }
          }
        }
      }


      if(totalpassing2 > totalpassing1)
      {
          posesion2et = posesion2et + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2et = shotsongoal2et + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             }
          }
        }
      }
         p++;
         mins++;
         if(defoff > 0)
         {
            --defoff;
         }
         }while(p <= 119);

        if(tp2 == ok2 && p >= 119)
        {
            fuckingpens = 1;
            ttp2 = 0;
            ook2 = 0;
            while(ttp2 == ook2)
            {
                ver = rand() % 201;
                if(shoot1 < ver)
                {
                  ttp2 = ttp2 + 1;
                }

                ver = rand() % 201;
                if(shoot2 < ver)
                {
                  ook2 = ook2 + 1;
                }
            }
        }


       }

        cout << "  FULL TIME - Press a key" << endl;
        (void)_getch();

         cout << endl << endl << "             FINAL RESULT" << endl;
         cout << endl << endl << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
         cout << "  HT:" << ht1 << "-" << ht2 << "  SHOTS ON GOAL: " << shotsongoal1 << "-" << shotsongoal2 << right
         << "  POSSESION: " << posesion1 << "-" << posesion2 << endl;

         recm << year << " " << right << setw(2) << gn << "R2: " << right << setw(20) << team1 << " " << tp2 << right << setw(20) << team2 << " " << ok2 << "  HT:" << ht1 << "-" << ht2 << right << setw(20) << "SHOTS ON GOAL: "
         << right << setw(4) << shotsongoal1 << "   - " << right << setw(4) << shotsongoal2 << right << setw(20) << "POSSESION: "
         << right << setw(4) << posesion1 << "   - " << right << setw(4) << posesion2;

         if(mins > 90)
         {
            recm << "  A.E.T ";
            cout << "  A.E.T ";
            if(fuckingpens == 1)
            {
            recm << right << setw(10)<< "PENS: " << ttp2 << "-" << ook2 << "  FT:" << ft1 << "-" << ft2 << setw(20) << "ETSHOTS: "
             << right << setw(4) << shotsongoal1et << "   - " << right << setw(4) << shotsongoal2et << right << setw(10) << "ETPOS: "
             << right << setw(4) << posesion1et << "   - " << right << setw(4) << posesion2et;
            cout << "  PENS: " << ttp2 << "-" << ook2 << "  FT:" << ft1 << "-" << ft2 << "  ETSHOTS: "
             << shotsongoal1et << " - " << shotsongoal2et << "  ETPOS: " << posesion1et << " - " << posesion2et;
            }
            else
            {
            recm << right << setw(18)<< "FT:" << ft1 << "-" << ft2 << setw(20) << "ETSHOTS: "
            << right << setw(4) << shotsongoal1et << "   - " << right << setw(4) << shotsongoal2et << right << setw(10) << "ETPOS: "
            << right << setw(4) << posesion1et << "   - " << right << setw(4) << posesion2et;
            cout << "  FT:" << ft1 << "-" << ft2 << "  ETSHOTS: " << shotsongoal1et << " - " << shotsongoal2et << "  ETPOS: "
            << posesion1et << " - " << posesion2et;
            }

            recm << endl;
            cout << endl;
         }
        else
         {
            recm << endl;
            cout << endl;
         }

        tp2 = tp2 + ttp2;
        ok2 = ok2 + ook2;


        if(tp2 > ok2)
        {
            m[tp1].changebalance(1000);
            pups.teamwonlost(tp1,3);
            pups.teamwonlost(ok1,0);
        }
        if(tp2 < ok2)
        {
            m[ok1].changebalance(1000);
            pups.teamwonlost(tp1,0);
            pups.teamwonlost(ok1,3);
        }






         if(gn == 8)
         {
             pups.resetgamenumber();
         }
         else
         {
            pups.gamenumberplusone();
         }



    }//second round end












    else if(round == 3)
    {

      gn = pups.showgamenumber();

    do{

       do{
       ct1 = rand() % 40;
       tp1 = pups.teamchecker(ct1,3);
       }while(tp1 == 100);

       do{
       ct2 = rand() % 40;
       ok1 = pups.teamchecker(ct2,3);
       }while(ok1 == 100);




       }while(tp1 == ok1);




         m[tp1].teamshow(team1);
         m[ok1].teamshow(team2);
         m[tp1].stadiumshow(stadium);
         at1 = m[tp1].attackshow();
         at2 = m[ok1].attackshow();
         df1 = m[tp1].defenceshow();
         df2 = m[ok1].defenceshow();
         ps1 = m[tp1].passingshow();
         ps2 = m[ok1].passingshow();
         shoot1 = m[tp1].shootingshow();
         shoot2 = m[ok1].shootingshow();
         cs1 = m[tp1].capacityshow();
         cs2 = m[ok1].capacityshow();


       cout << endl << endl << right << setw(2) << gn << "ROUND 3 ALL ATLANTIS CUP:   " << team1 << "  VS  " << team2 << "  at: " << stadium << "  cap:" << cs1 << endl;
       (void)_getch();

       tp2 = 0;
       ok2 = 0;
       shotsongoal1 = 0;
       shotsongoal2 = 0;
       posesion1 = 0;
       posesion2 = 0;

       if (cs1 > cs2)
       {
          bigadvantage = (cs1 - cs2) / CUPSUPERIORITY;
          ps1 = ps1 + bigadvantage;
       }

       if (cs2 > cs1)
       {
          bigadvantage = (cs2 - cs1) / CUPSUPERIORITY;
          ps2 = ps2 + bigadvantage;
       }



        for(p = 0; p < 90; p++)
        {

      homeadvantage = rand() % 11 + 2;
      at0 = rand() % 151;
      df0 = rand() % 101 + 100;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + 100;
      ps4 = rand() % 151;

      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;

      totalpassing1 = totalpassing1 + homeadvantage;
      ver = rand() % 101;





     if(totalpassing1 >= totalpassing2)
      {
          posesion1 = posesion1 + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1 = shotsongoal1 + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             }
          }
        }
      }



       if(totalpassing2 > totalpassing1)
      {
          posesion2 = posesion2 + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2 = shotsongoal2 + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             }
          }
        }
      if(p == 45)
       {
          ht1 = tp2;
          ht2 = ok2;
       }
      }
    }

     if(tp2 == ok2)
       {
      chrono::seconds dura(1);
      this_thread::sleep_for(dura);
      p = 90;
      defoff = 100;
      shotsongoal1et = 0;
      shotsongoal2et = 0;
      posesion1et = 0;
      posesion2et = 0;
      ft1 = tp2;
      ft2 = ok2;

      do{

      homeadvantage = rand() % 11 + 2;
      at0 = rand() % 151;
      df0 = rand() % 101 + defoff;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + defoff;
      ps4 = rand() % 151;


      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;

      totalpassing1 = totalpassing1 + homeadvantage;
      ver = rand() % 101;


     if(totalpassing1 >= totalpassing2)
      {
          posesion1et = posesion1et + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1et = shotsongoal1et + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             }
          }
        }
      }


      if(totalpassing2 > totalpassing1)
      {
          posesion2et = posesion2et + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2et = shotsongoal2et + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             }
          }
        }
      }
         p++;
         mins++;
         if(defoff > 0)
         {
            --defoff;
         }
        }while(p <= 119);

        if(tp2 == ok2 && p > 119)
        {
            fuckingpens = 1;
            while(ttp2 == ook2)
            {
                ver = rand() % 201;
                if(shoot1 < ver)
                {
                  ttp2 = ttp2 + 1;
                }

                ver = rand() % 201;
                if(shoot2 < ver)
                {
                  ook2 = ook2 + 1;
                }
            }
        }


       }

        cout << "  FULL TIME - Press a key" << endl;
        (void)_getch();

         cout << endl << endl << "             FINAL RESULT" << endl;
         cout << endl << endl << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
         cout << "  HT:" << ht1 << "-" << ht2 << "  SHOTS ON GOAL: " << shotsongoal1 << "-" << shotsongoal2 << right
         << "  POSSESION: " << posesion1 << "-" << posesion2 << endl;

         recm << year << " " << right << setw(2) << gn << "R3: " << right << setw(20) << team1 << " " << tp2 << right << setw(20) << team2 << " " << ok2 << "  HT:" << ht1 << "-" << ht2 << right << setw(20) << "SHOTS ON GOAL: "
         << right << setw(4) << shotsongoal1 << "   - " << right << setw(4) << shotsongoal2 << right << setw(20) << "POSSESION: "
         << right << setw(4) << posesion1 << "   - " << right << setw(4) << posesion2;

         if(mins > 90)
         {
            recm << "  A.E.T ";
            cout << "  A.E.T ";
            if(fuckingpens == 1)
            {
            recm << right << setw(10)<< "PENS: " << ttp2 << "-" << ook2 << "  FT:" << ft1 << "-" << ft2 << setw(20) << "ETSHOTS: "
             << right << setw(4) << shotsongoal1et << "   - " << right << setw(4) << shotsongoal2et << right << setw(10) << "ETPOS: "
             << right << setw(4) << posesion1et << "   - " << right << setw(4) << posesion2et;
            cout << "  PENS: " << ttp2 << "-" << ook2 << "  FT:" << ft1 << "-" << ft2 << "  ETSHOTS: "
             << shotsongoal1et << " - " << shotsongoal2et << "  ETPOS: " << posesion1et << " - " << posesion2et;
            }
            else
            {
            recm << right << setw(18)<< "FT:" << ft1 << "-" << ft2 << setw(20) << "ETSHOTS: "
            << right << setw(4) << shotsongoal1et << "   - " << right << setw(4) << shotsongoal2et << right << setw(10) << "ETPOS: "
            << right << setw(4) << posesion1et << "   - " << right << setw(4) << posesion2et;
            cout << "  FT:" << ft1 << "-" << ft2 << "  ETSHOTS: " << shotsongoal1et << " - " << shotsongoal2et << "  ETPOS: "
            << posesion1et << " - " << posesion2et;
            }

            recm << endl;
            cout << endl;
         }
        else
         {
            recm << endl;
            cout << endl;
         }

        tp2 = tp2 + ttp2;
        ok2 = ok2 + ook2;


        if(tp2 > ok2)
        {
            m[tp1].changebalance(10000);
            pups.teamwonlost(tp1,4);
            pups.teamwonlost(ok1,0);
        }
        if(tp2 < ok2)
        {
            m[ok1].changebalance(10000);
            pups.teamwonlost(tp1,0);
            pups.teamwonlost(ok1,4);
        }






         if(gn == 8)
         {
             pups.resetgamenumber();
         }
         else
         {
            pups.gamenumberplusone();
         }


    }//third round end













 else if(round == 4)
    {

       gn = pups.showgamenumber();

    do{

       do{
       ct1 = rand() % 40;
       tp1 = pups.teamchecker(ct1,4);
       }while(tp1 == 100);

       do{
       ct2 = rand() % 40;
       ok1 = pups.teamchecker(ct2,4);
       }while(ok1 == 100);




       }while(tp1 == ok1);




         m[tp1].teamshow(team1);
         m[ok1].teamshow(team2);
         m[tp1].stadiumshow(stadium);
         at1 = m[tp1].attackshow();
         at2 = m[ok1].attackshow();
         df1 = m[tp1].defenceshow();
         df2 = m[ok1].defenceshow();
         ps1 = m[tp1].passingshow();
         ps2 = m[ok1].passingshow();
         shoot1 = m[tp1].shootingshow();
         shoot2 = m[ok1].shootingshow();
         cs1 = m[tp1].capacityshow();
         cs2 = m[ok1].capacityshow();


       cout << endl << endl << right << setw(2) << gn << " QUARTER FINAL ALL ATLANTIS CUP:   " << team1 << "  VS  " << team2 << "  at: " << stadium << "  cap:" << cs1 << endl;
      (void)_getch();

       tp2 = 0;
       ok2 = 0;
       shotsongoal1 = 0;
       shotsongoal2 = 0;
       posesion1 = 0;
       posesion2 = 0;


       if (cs1 > cs2)
       {
          bigadvantage = (cs1 - cs2) / CUPSUPERIORITY;
          ps1 = ps1 + bigadvantage;
       }

       if (cs2 > cs1)
       {
          bigadvantage = (cs2 - cs1) / CUPSUPERIORITY;
          ps2 = ps2 + bigadvantage;
       }


        for(p = 0; p < 90; p++)
        {

      homeadvantage = rand() % 11 + 2;
      at0 = rand() % 151;
      df0 = rand() % 101 + 100;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + 100;
      ps4 = rand() % 151;


      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;

      totalpassing1 = totalpassing1 + homeadvantage;
      ver = rand() % 101;





     if(totalpassing1 >= totalpassing2)
      {
          posesion1 = posesion1 + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1 = shotsongoal1 + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             }
          }
        }
      }



       if(totalpassing2 > totalpassing1)
      {
          posesion2 = posesion2 + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2 = shotsongoal2 + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             }
          }
        }
      }
      if(p == 45)
       {
          ht1 = tp2;
          ht2 = ok2;
       }
  }

     if(tp2 == ok2)
       {
      chrono::seconds dura(1);
      this_thread::sleep_for(dura);
      p = 90;
      defoff = 100;
      shotsongoal1et = 0;
      shotsongoal2et = 0;
      posesion1et = 0;
      posesion2et = 0;
      ft1 = tp2;
      ft2 = ok2;

      do{

      homeadvantage = rand() % 11 + 2;
      at0 = rand() % 151;
      df0 = rand() % 101 + defoff;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + defoff;
      ps4 = rand() % 151;


      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;

      totalpassing1 = totalpassing1 + homeadvantage;
      ver = rand() % 101;


     if(totalpassing1 >= totalpassing2)
      {
          posesion1et = posesion1et + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1et = shotsongoal1et + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             }
          }
        }
      }


      if(totalpassing2 > totalpassing1)
      {
          posesion2et = posesion2et + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2et = shotsongoal2et + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             }
          }
        }
      }
         p++;
         mins++;
         if(defoff > 0)
         {
            --defoff;
         }
        }while(p <= 119);

        if(tp2 == ok2 && p > 119)
        {
            fuckingpens = 1;
            while(ttp2 == ook2)
            {
                ver = rand() % 201;
                if(shoot1 < ver)
                {
                  ttp2 = ttp2 + 1;
                }

                ver = rand() % 201;
                if(shoot2 < ver)
                {
                  ook2 = ook2 + 1;
                }
            }
        }

      }

        cout << "  FULL TIME - Press a key" << endl;
        (void)_getch();

         cout << endl << endl << "             FINAL RESULT" << endl;
         cout << endl << endl << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
         cout << "  HT:" << ht1 << "-" << ht2 << "  SHOTS ON GOAL: " << shotsongoal1 << "-" << shotsongoal2 << right
         << "  POSSESION: " << posesion1 << "-" << posesion2 << endl;

         recm << year << " " << right << setw(2) << gn << "QF: " << right << setw(20) << team1 << " " << tp2 << right << setw(20) << team2 << " " << ok2 << "  HT:" << ht1 << "-" << ht2 << right << setw(20) << "SHOTS ON GOAL: "
         << right << setw(4) << shotsongoal1 << "   - " << right << setw(4) << shotsongoal2 << right << setw(20) << "POSSESION: "
         << right << setw(4) << posesion1 << "   - " << right << setw(4) << posesion2;

       if(mins > 90)
         {
            recm << "  A.E.T ";
            cout << "  A.E.T ";
            if(fuckingpens == 1)
            {
            recm << right << setw(10)<< "PENS: " << ttp2 << "-" << ook2 << "  FT:" << ft1 << "-" << ft2 << setw(20) << "ETSHOTS: "
             << right << setw(4) << shotsongoal1et << "   - " << right << setw(4) << shotsongoal2et << right << setw(10) << "ETPOS: "
             << right << setw(4) << posesion1et << "   - " << right << setw(4) << posesion2et;
            cout << "  PENS: " << ttp2 << "-" << ook2 << "  FT:" << ft1 << "-" << ft2 << "  ETSHOTS: "
             << shotsongoal1et << " - " << shotsongoal2et << "  ETPOS: " << posesion1et << " - " << posesion2et;
            }
            else
            {
            recm << right << setw(18)<< "FT:" << ft1 << "-" << ft2 << setw(20) << "ETSHOTS: "
            << right << setw(4) << shotsongoal1et << "   - " << right << setw(4) << shotsongoal2et << right << setw(10) << "ETPOS: "
            << right << setw(4) << posesion1et << "   - " << right << setw(4) << posesion2et;
            cout << "  FT:" << ft1 << "-" << ft2 << "  ETSHOTS: " << shotsongoal1et << " - " << shotsongoal2et << "  ETPOS: "
            << posesion1et << " - " << posesion2et;
            }

            recm << endl;
            cout << endl;
         }
        else
         {
            recm << endl;
            cout << endl;
         }

        tp2 = tp2 + ttp2;
        ok2 = ok2 + ook2;

        if(tp2 > ok2)
        {
            m[tp1].changebalance(100000);
            pups.teamwonlost(tp1,5);
            pups.teamwonlost(ok1,0);
        }
        if(tp2 < ok2)
        {
            m[ok1].changebalance(100000);
            pups.teamwonlost(tp1,0);
            pups.teamwonlost(ok1,5);
        }





          if(gn == 4)
         {
             pups.resetgamenumber();
         }
         else
         {
            pups.gamenumberplusone();
         }

    }//quarter round end











 else if(round == 5)
    {

      gn = pups.showgamenumber();

    do{

       do{
       ct1 = rand() % 40;
       tp1 = pups.teamchecker(ct1,5);
       }while(tp1 == 100);

       do{
       ct2 = rand() % 40;
       ok1 = pups.teamchecker(ct2,5);
       }while(ok1 == 100);




       }while(tp1 == ok1);




         m[tp1].teamshow(team1);
         m[ok1].teamshow(team2);
         at1 = m[tp1].attackshow();
         at2 = m[ok1].attackshow();
         df1 = m[tp1].defenceshow();
         df2 = m[ok1].defenceshow();
         ps1 = m[tp1].passingshow();
         ps2 = m[ok1].passingshow();
         shoot1 = m[tp1].shootingshow();
         shoot2 = m[ok1].shootingshow();
         cs1 = m[tp1].capacityshow();
         cs2 = m[ok1].capacityshow();


       cout << endl << endl << right << setw(2) << gn << " SEMI FINAL ALL ATLANTIS CUP:   " << team1 << "  VS  " << team2 << " - White City Stadium" << "  cap:50000" << endl;
       (void)_getch();


       tp2 = 0;
       ok2 = 0;
       shotsongoal1 = 0;
       shotsongoal2 = 0;
       posesion1 = 0;
       posesion2 = 0;


       if (cs1 > cs2)
       {
          bigadvantage = (cs1 - cs2) / SUPERIORITY;
          ps1 = ps1 + bigadvantage;
       }

       if (cs2 > cs1)
       {
          bigadvantage = (cs2 - cs1) / SUPERIORITY;
          ps2 = ps2 + bigadvantage;
       }



        for(p = 0; p < 90; p++)
        {

      at0 = rand() % 151;
      df0 = rand() % 101 + 100;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + 100;
      ps4 = rand() % 151;


      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;


      ver = rand() % 101;





     if(totalpassing1 >= totalpassing2)
      {
          posesion1 = posesion1 + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1 = shotsongoal1 + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             }
          }
        }
      }



       if(totalpassing2 > totalpassing1)
      {
          posesion2 = posesion2 + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2 = shotsongoal2 + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             }
          }
        }

      if(p == 45)
       {
          ht1 = tp2;
          ht2 = ok2;
       }
      }
  }

     if(tp2 == ok2)
       {
      chrono::seconds dura(1);
      this_thread::sleep_for(dura);
      p = 90;
      defoff = 100;
      shotsongoal1et = 0;
      shotsongoal2et = 0;
      posesion1et = 0;
      posesion2et = 0;
      ft1 = tp2;
      ft2 = ok2;

      do{

      at0 = rand() % 151;
      df0 = rand() % 101 + defoff;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + defoff;
      ps4 = rand() % 151;


      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;


      ver = rand() % 101;


     if(totalpassing1 >= totalpassing2)
      {
          posesion1et = posesion1et + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1et = shotsongoal1et + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             }
          }
        }
      }


      if(totalpassing2 > totalpassing1)
      {
          posesion2et = posesion2et + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2et = shotsongoal2et + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             }
          }
        }
      }
         p++;
         mins++;
         if(defoff > 0)
         {
            --defoff;
         }
         }while(p <= 119);

        if(tp2 == ok2 && p > 119)
        {
            fuckingpens = 1;
            while(ttp2 == ook2)
            {
                ver = rand() % 201;
                if(shoot1 < ver)
                {
                  ttp2 = ttp2 + 1;
                }

                ver = rand() % 201;
                if(shoot2 < ver)
                {
                  ook2 = ook2 + 1;
                }
            }
        }
     }

        cout << "  FULL TIME - Press a key" << endl;
        (void)_getch();

         cout << endl << endl << "             FINAL RESULT" << endl;
         cout << endl << endl << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
         cout << "  HT:" << ht1 << "-" << ht2 << "  SHOTS ON GOAL: " << shotsongoal1 << "-" << shotsongoal2 << right
         << "  POSSESION: " << posesion1 << "-" << posesion2 << endl;

         recm << year << " " << right << setw(2) << gn << "SF: " << right << setw(20) << team1 << " " << tp2 << right << setw(20) << team2 << " " << ok2 << "  HT:" << ht1 << "-" << ht2 << right << setw(20) << "SHOTS ON GOAL: "
         << right << setw(4) << shotsongoal1 << "   - " << right << setw(4) << shotsongoal2 << right << setw(20) << "POSSESION: "
         << right << setw(4) << posesion1 << "   - " << right << setw(4) << posesion2;

        if(mins > 90)
         {
            recm << "  A.E.T ";
            cout << "  A.E.T ";
            if(fuckingpens == 1)
            {
            recm << right << setw(10)<< "PENS: " << ttp2 << "-" << ook2 << "  FT:" << ft1 << "-" << ft2 << setw(20) << "ETSHOTS: "
             << right << setw(4) << shotsongoal1et << "   - " << right << setw(4) << shotsongoal2et << right << setw(10) << "ETPOS: "
             << right << setw(4) << posesion1et << "   - " << right << setw(4) << posesion2et;
            cout << "  PENS: " << ttp2 << "-" << ook2 << "  FT:" << ft1 << "-" << ft2 << "  ETSHOTS: "
             << shotsongoal1et << " - " << shotsongoal2et << "  ETPOS: " << posesion1et << " - " << posesion2et;
            }
            else
            {
            recm << right << setw(18)<< "FT:" << ft1 << "-" << ft2 << setw(20) << "ETSHOTS: "
            << right << setw(4) << shotsongoal1et << "   - " << right << setw(4) << shotsongoal2et << right << setw(10) << "ETPOS: "
            << right << setw(4) << posesion1et << "   - " << right << setw(4) << posesion2et;
            cout << "  FT:" << ft1 << "-" << ft2 << "  ETSHOTS: " << shotsongoal1et << " - " << shotsongoal2et << "  ETPOS: "
            << posesion1et << " - " << posesion2et;
            }

            recm << endl;
            cout << endl;
         }
        else
         {
            recm << endl;
            cout << endl;
         }

        tp2 = tp2 + ttp2;
        ok2 = ok2 + ook2;


        if(tp2 > ok2)
        {
            m[tp1].changebalance(1000000);
            pups.teamwonlost(tp1,6);
            pups.teamwonlost(ok1,0);
        }
        if(tp2 < ok2)
        {
            m[ok1].changebalance(1000000);
            pups.teamwonlost(tp1,0);
            pups.teamwonlost(ok1,6);
        }





          if(gn == 2)
         {
             pups.resetgamenumber();
         }
         else
         {
            pups.gamenumberplusone();
         }


    }//semi round end








 else if(round == 6)
    {

      gn = pups.showgamenumber();

    do{

       do{
       ct1 = rand() % 40;
       tp1 = pups.teamchecker(ct1,6);
       }while(tp1 == 100);

       do{
       ct2 = rand() % 40;
       ok1 = pups.teamchecker(ct2,6);
       }while(ok1 == 100);




       }while(tp1 == ok1);




         m[tp1].teamshow(team1);
         m[ok1].teamshow(team2);
         at1 = m[tp1].attackshow();
         at2 = m[ok1].attackshow();
         df1 = m[tp1].defenceshow();
         df2 = m[ok1].defenceshow();
         ps1 = m[tp1].passingshow();
         ps2 = m[ok1].passingshow();
         shoot1 = m[tp1].shootingshow();
         shoot2 = m[ok1].shootingshow();
         cs1 = m[tp1].capacityshow();
         cs2 = m[ok1].capacityshow();



       cout << endl << endl << right << setw(2) << gn << " FINAL - ALL ATLANTIS CUP:   " << team1 << "  VS  " << team2 << " - Capitalis Stadium" << "  cap:100000" << endl;
       cout << "  KICK OFF - Press a key" << endl;
       (void)_getch();

       tp2 = 0;
       ok2 = 0;
       shotsongoal1 = 0;
       shotsongoal2 = 0;
       posesion1 = 0;
       posesion2 = 0;


      if (cs1 > cs2)
       {
          bigadvantage = (cs1 - cs2) / SUPERIORITY;
          ps1 = ps1 + bigadvantage;
       }

       if (cs2 > cs1)
       {
          bigadvantage = (cs2 - cs1) / SUPERIORITY;
          ps2 = ps2 + bigadvantage;
       }



      for(p = 0; p < 90; p++)
        {

      at0 = rand() % 151;
      df0 = rand() % 101 + 100;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + 100;
      ps4 = rand() % 151;



      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;

      ver = rand() % 101;

      if(p == 45)
      {
        cout << "  HALF TIME - Press a key" << endl;
        (void)_getch();
          ht1 = tp2;
          ht2 = ok2;
      }






      if(totalpassing1 >= totalpassing2)
      {
          posesion1 = posesion1 + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1 = shotsongoal1 + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             cout << "  GOAL!! Press a key" << endl;
             (void)_getch();
             }
          }
        }
      }


      if(totalpassing2 > totalpassing1)
      {
          posesion2 = posesion2 + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2 = shotsongoal2 + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             cout << "  GOAL!! Press a key" << endl;
             (void)_getch();
             }
          }
        }
      }


       cout << "minute " << p+1 << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
       chrono::seconds dura(1);
       this_thread::sleep_for(dura);

        }

     if(tp2 == ok2)
       {
      cout << "Extra Time " << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
      cout << "Press a key" << endl;
      (void)_getch();
      p = 90;
      defoff = 100;
      shotsongoal1et = 0;
      shotsongoal2et = 0;
      posesion1et = 0;
      posesion2et = 0;
      ft1 = tp2;
      ft2 = ok2;

      do{

      at0 = rand() % 151;
      df0 = rand() % 101 + defoff;
      ps0 = rand() % 151;

      at4 = rand() % 151;
      df4 = rand() % 101 + defoff;
      ps4 = rand() % 151;



      totalattack1 = at1 + at0;
      totalattack2 = at2 + at4;
      totaldefence1 = df1 + df0;
      totaldefence2 = df2 + df4;
      totalpassing1 = ps1 + ps0;
      totalpassing2 = ps2 + ps4;

      ver = rand() % 101;


      if(totalpassing1 >= totalpassing2)
      {
          posesion1et = posesion1et + 1;
        if(totalpassing1 > totaldefence2)
        {
          shotsongoal1et = shotsongoal1et + 1;
          if(totalattack1 > totaldefence2)
          {
             if(shoot1 < ver)
             {
             tp2 = tp2 + 1;
             cout << "  GOAL!! Press a key" << endl;
             (void)_getch();
             }
          }
        }
      }


      if(totalpassing2 > totalpassing1)
      {
          posesion2et = posesion2et + 1;
        if(totalpassing2 > totaldefence1)
        {
            shotsongoal2et = shotsongoal2et + 1;
          if(totalattack2 > totaldefence1)
          {
             if(shoot2 < ver)
             {
             ok2 = ok2 + 1;
             cout << "  GOAL!! Press a key" << endl;
             (void)_getch();
             }
          }
        }
      }

       cout << "extra time minute " << p+1 << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
       chrono::seconds dura(1);
       this_thread::sleep_for(dura);
       p++;
       mins++;
       if(defoff > 0)
         {
            --defoff;
         }
         }while(p <= 119);

        if(tp2 == ok2 && p > 119)
        {
            cout << "PENALTIES...." << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl << endl;
            fuckingpens = 1;
            while(ttp2 == ook2)
            {
                pennum++;
                cout << "Penalty number:  " << pennum << "   " << team1 << " " << ttp2 << "   " << team2 << " " << ook2 << endl << endl;
                ver = rand() % 201;
                cout << team1 << "  STEPS UP......" << endl << endl;
                (void)_getch();
                if(shoot1 < ver)
                {
                  ttp2 = ttp2 + 1;
                  cout << "  GOAL!! Press a key" << endl << endl;
                  (void)_getch();
                }
                else
                {
                  cout << "  MISSED!! Press a key" << endl << endl;
                  (void)_getch();
                }

                ver = rand() % 201;
                cout << team2 << "  STEPS UP......" << endl << endl;
                (void)_getch();
                if(shoot2 < ver)
                {
                  ook2 = ook2 + 1;
                  cout << "  GOAL!! Press a key" << endl << endl;
                  (void)_getch();
                }
                else
                {
                  cout << "  MISSED!! Press a key" << endl << endl;
                  (void)_getch();
                }
            }
        }


       }




        cout << "  FULL TIME - Press a key" << endl;
        (void)_getch();

         cout << endl << endl << "             FINAL RESULT" << endl;
         cout << endl << endl << "   " << team1 << " " << tp2 << "   " << team2 << " " << ok2 << endl;
         cout << "  HT:" << ht1 << "-" << ht2 << "  SHOTS ON GOAL: " << shotsongoal1 << "-" << shotsongoal2 << right
         << "  POSSESION: " << posesion1 << "-" << posesion2 << endl;

         recm << year << " " << right << setw(2) << "ALL ATLANTIS CUP FINAL: " << right << setw(20) << team1 << " " << tp2 << right << setw(20) << team2 << " " << ok2 << "  HT:" << ht1 << "-" << ht2 << right << setw(20) << "SHOTS ON GOAL: "
         << right << setw(4) << shotsongoal1 << "   - " << right << setw(4) << shotsongoal2 << right << setw(20) << "POSSESION: "
         << right << setw(4) << posesion1 << "   - " << right << setw(4) << posesion2;

         if(mins > 90)
         {
            recm << "  A.E.T ";
            cout << "  A.E.T ";
            if(fuckingpens == 1)
            {
            recm << right << setw(10)<< "PENS: " << ttp2 << "-" << ook2 << "  FT:" << ft1 << "-" << ft2 << setw(20) << "ETSHOTS: "
             << right << setw(4) << shotsongoal1et << "   - " << right << setw(4) << shotsongoal2et << right << setw(10) << "ETPOS: "
             << right << setw(4) << posesion1et << "   - " << right << setw(4) << posesion2et;
            cout << "  PENS: " << ttp2 << "-" << ook2 << "  FT:" << ft1 << "-" << ft2 << "  ETSHOTS: "
             << shotsongoal1et << " - " << shotsongoal2et << "  ETPOS: " << posesion1et << " - " << posesion2et;
            }
            else
            {
            recm << right << setw(18)<< "FT:" << ft1 << "-" << ft2 << setw(20) << "ETSHOTS: "
            << right << setw(4) << shotsongoal1et << "   - " << right << setw(4) << shotsongoal2et << right << setw(10) << "ETPOS: "
            << right << setw(4) << posesion1et << "   - " << right << setw(4) << posesion2et;
            cout << "  FT:" << ft1 << "-" << ft2 << "  ETSHOTS: " << shotsongoal1et << " - " << shotsongoal2et << "  ETPOS: "
            << posesion1et << " - " << posesion2et;
            }

            recm << endl;
            cout << endl;
         }
        else
         {
            recm << endl;
            cout << endl;
         }

        tp2 = tp2 + ttp2;
        ok2 = ok2 + ook2;

        if(tp2 > ok2)
        {
            m[tp1].changebalance(10000000);
            pups.teamwonlost(tp1,0);
            pups.teamwonlost(ok1,0);
        }
        if(tp2 < ok2)
        {
            m[ok1].changebalance(10000000);
            pups.teamwonlost(tp1,0);
            pups.teamwonlost(ok1,0);
        }




        pups.resetgamenumber();

    }//final round end



   else{



            cout << "  ALL PLAYED!!!!!!" << endl;

    }


      gm.open("TEAMS.BIN",ios_base::binary|ios_base::out);
        if(gm.fail())
        {
          cout << "Could not open teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }


        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
        {
         m[p].save(gm);
        }

        gm.close();



     fx.open("CUP.BIN",ios_base::binary|ios_base::out);
        if(fx.fail())
        {
          cout << "Could not open cup file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

     pups.save(fx);


     fx.close();






      recm.close();


     delete [] m;

//      m = nullptr;







    (void)_getch();





 return;
}
