#ifndef FIXTURES_H_INCLUDED
#define FIXTURES_H_INCLUDED
#include <fstream>

using namespace std;


class fixtureselite
{
    int teamturn;
    int gamenumber;
    char week[9];
    char teamvteam0[9];
    char teamvteam1[9];
    char teamvteam2[9];
    char teamvteam3[9];
    char teamvteam4[9];
    char teamvteam5[9];
    char teamvteam6[9];
    char teamvteam7[9];




    public:
    fixtureselite();
    ~fixtureselite();


    int teamchecker(int tc1);
    int checkturn();
    int checkturntwo();
    int checkgamenumber();
    void plusonegamenumber();
    void fullseasononetwo();
    void startfullseasononetwo();
    void turnplus();


    void save(fstream& op);
    int load(fstream& ip);
};
#endif // FIXTURES_H_INCLUDED
