#include "footballgod.h"



void tableselite(void)
{
        fstream gm;
        int tpoints1, tpoints2, goaldiff1, goaldiff2, p, j, u, e;
        int pl1, pl2, wins1, wins2, draws1, draws2, loses1, loses2;
        int gf1, gf2, ga1, ga2;
        char mst1[80];
        char mst2[80];


        gm.open("TEAMS.BIN",ios_base::binary|ios_base::in);
        if(gm.fail())
        {
          cout << "Could not open Teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

         team* igm = new team[NUM_OF_TEAMS_TOTAL];

        // vector<team> igm (NUM_OF_TEAMS_TOTAL);

        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
         {
           igm[p].load(gm);
         }

        gm.close();


        cout << endl << endl << endl;



           for (p = 0; p < 8; p++)
            {
              for (j = 0; j < 7; j++)
               {

                 tpoints1  = igm[j].showpoints();
                 tpoints2 = igm[j+1].showpoints();
                 igm[j].teamshow(mst1);
                 igm[j+1].teamshow(mst2);
                 pl1  = igm[j].showplayed();
                 pl2  = igm[j+1].showplayed();
                 wins1  = igm[j].showwins();
                 wins2  = igm[j+1].showwins();
                 draws1 = igm[j].showdraws();
                 draws2 = igm[j+1].showdraws();
                 loses1 = igm[j].showloses();
                 loses2 = igm[j+1].showloses();
                 gf1 = igm[j].showgoalsfor();
                 gf2 = igm[j+1].showgoalsfor();
                 ga1 = igm[j].showgoalsags();
                 ga2 = igm[j+1].showgoalsags();
                 goaldiff1  = igm[j].showgoaldiff();
                 goaldiff2  = igm[j+1].showgoaldiff();



                 if (tpoints1 < tpoints2)
                  {
                    igm[j].swapteam(mst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2);
                    igm[j+1].swapteam(mst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1);
                  }

                  if (tpoints1 == tpoints2)
                   {
                        if (goaldiff1 < goaldiff2)
                        {
                           igm[j].swapteam(mst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2);
                           igm[j+1].swapteam(mst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1);
                        }

                        if (goaldiff1 == goaldiff2)
                       {
                          if (gf1 < gf2)
                           {
                              igm[j].swapteam(mst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2);
                              igm[j+1].swapteam(mst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1);
                           }

                          if (gf1 == gf2)
                          {
                               if (ga1 > ga2)
                                {
                                igm[j].swapteam(mst2,pl2,wins2,draws2,loses2,gf2,ga2,goaldiff2,tpoints2);
                                igm[j+1].swapteam(mst1,pl1,wins1,draws1,loses1,gf1,ga1,goaldiff1,tpoints1);
                                }
                          }
                      }
                 }
              }
            }



         u = 1;



         cout << "                        ATLANTIS UNION ELITE                       " << endl;
         cout << "-------------------------------------------------------------------" << endl;
         cout << "                            PL   W   D   L    GF    GA    GD    PTS" << endl << endl;
         cout << "___________________________________________________________________" << endl;

         for (e = 0; e < 8; e++)
         {

           cout << "# " << setw(2) << u << "  ";
           igm[e].showteams();
           if(u == 1 || u == 7)
              cout <<"____________________________________________________________________" << endl;
           u++;
        }


      cout <<"____________________________________________________________________" << endl << endl;



       cout << endl << endl;

       delete [] igm;

//       igm = nullptr;


        return;


}
