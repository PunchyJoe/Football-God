#include "footballgod.h"



void sellasetts(void)
{

      fstream gm;
      fstream yn;

      char sitdown[4];
      char wantcon;

      int u = 1;
      int p, e;
      int teamcap;
      int year;
      int revenue;


       srand ( (unsigned int)time(NULL) );

      yn.open("YEAR.BIN",ios_base::binary|ios_base::in);
        if(yn.fail())
        {
          cout << "Could not open Year file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }

        yn.read((char *)&year, sizeof(year));

        yn.close();



       cout << "Sell assets if over or near bankrupt level of -100000000" << endl;
       cout << " Do You want to continue? Y/N" << endl;
       cin  >> wantcon;

       if(wantcon != 'Y' && wantcon != 'y')
       {
         return;
       }



       team* igm = new team[NUM_OF_TEAMS_TOTAL];

       gm.open("TEAMS.BIN",ios_base::binary|ios_base::in);
        if(gm.fail())
        {
          cout << "Could not open teams file - Press a key" << endl;
          (void)_getch();
          exit(1);
        }


        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
         {
            igm[p].load(gm);
         }

        gm.close();






         cout << "                        ATLANTIS ALL TEAMS                              " << endl;
         cout << "------------------------------------------------------------------------" << endl;
         cout << "                         Div  Reg        Bal                  Sta(cap)  " << endl;
         cout << "------------------------------------------------------------------------" << endl;


         for (e = 0; e < (NUM_OF_TEAMS_TOTAL - 2); e++)
         {

           cout << "# " << setw(2) << u << "  ";
           igm[e].showteamsshow();
           u++;
         }

        do
        {
        cout << endl << "Sell some coaching staff and players" << endl;
        cin >> sitdown;
        teamcap = atoi(sitdown);
        cout << endl;

        }while(teamcap <= 0 || teamcap > 40);

        teamcap = teamcap - 1;

        revenue = igm[teamcap].sellsellsell(year);
        cout << "The below team sold some coaching staff and players" << endl;
        cout << "This generated: " << revenue << " in revenue" << endl;
        igm[teamcap].showteamsshow();

        gm.open("TEAMS.BIN",ios_base::binary|ios_base::out);
        if(gm.fail())
            {
               cout << "Could not open save teams file - Press a key" << endl;
               (void)_getch();
                exit(1);
            }

        for(p = 0; p < NUM_OF_TEAMS_TOTAL; p++)
            {
               igm[p].save(gm);
            }

        gm.close();




        delete [] igm;

        (void)_getch();

        return;


}
